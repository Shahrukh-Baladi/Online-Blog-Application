<?php
			use PHPMailer\PHPMailer\PHPMailer;
		    use PHPMailer\PHPMailer\SMTP;
		    use PHPMailer\PHPMailer\Exception;

		    require 'PHPMailer/src/PHPMailer.php';
		    require 'PHPMailer/src/SMTP.php';
		    require 'PHPMailer/src/Exception.php';

		    include_once("Connection/Connection.php");
			session_start();

if(isset($_POST['forget'])){



		$email = $_POST['email'];

		$random_password = rand(10000, 99999);
		$flag = true;



		$forget_query = "SELECT * FROM `user` 
		WHERE `user`.`email` = ?";

		$statement = mysqli_prepare($connection,$forget_query);

		mysqli_stmt_bind_param($statement,"s",$email);

		mysqli_stmt_execute($statement);

		$forget = mysqli_stmt_get_result($statement);



		if($forget->num_rows > 0)
		{
			while($forget_info = mysqli_fetch_assoc($forget)){
				
				if($email==$forget_info['email']){
					$random_password = rand(10000, 99999);

					
		$forget_password_query = "UPDATE `user` SET password = ?
		WHERE `user`.`email` = ?";
		
		$statement = mysqli_prepare($connection, $forget_password_query);
		
		mysqli_stmt_bind_param($statement,'ss',$random_password, $email);
		
		
		$result = mysqli_stmt_execute($statement);

					if($result){

						$flag=false;

						$mail = new PHPMailer();
				        $mail->isSMTP();
				        $mail->Host = 'smtp.gmail.com';
				        $mail->Port = 587;
				        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
				        $mail->SMTPAuth = true;
				        $mail->Username = 'sameerbaladi9@gmail.com';
				        $mail->Password = 'jrbzedbupgmhwfib';
				        $mail->setFrom($email, $first_name);
				        $mail->addReplyTo($email, 'User');
				        $mail->AddCc($email);
				        $mail->addAddress('sameerbaladi9@gmail.com', 'Admin');
				        $mail->Subject = 'Request For Reset Password';
				        $mail->msgHTML("We Have Updated Your Password Your New Password Is \nPassword: $random_password");
				        $mail->send();


							$msg = "Password Updated Successfully, Check Your Email";
					        header("location: forget_password.php?msg=$msg&color=green"); 

					}
					     	 

					    else
					    {
					        $msg = "Try Again";
					        header("location: forget_password.php?msg=$msg&color=green");  
					       
					    }
					}

	}
	}
	if ($flag) {
		header('location:forget_password.php?msg=Please Enter Valid Email');
		
	}

}





	
	?>