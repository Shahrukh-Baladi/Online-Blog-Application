<?php

  

    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    require 'PHPMailer/src/PHPMailer.php';
    require 'PHPMailer/src/SMTP.php';
    require 'PHPMailer/src/Exception.php';

    require_once("Connection/Connection.php");      
    require_once('Session.php');
    require_once('FPDF/fpdf/fpdf.php');


    date_default_timezone_set("Asia/karachi");


    
    
if(isset($_POST['Register']))
{
    
    extract($_POST);

    $alpha_pattern     = "/^[A-Z]{1}[a-z]{2,}$/";
    $email_pattern     = "/^[a-z]{2,6}[0-9]{1,3}[@][a-z]{5,8}[.][a-z]{2,5}$/";
    $password_pattern 	  =  "/^[A-Za-z]\w{7,14}$/";
    $address_pattern     = "/^[A-z]{4,20}/";
    

    $flag = true;
	$error_msg = null;

	if ($first_name == "") {
		$flag = false;
		$error_msg.="Please Enter the First Name !...";
	}else{

		if( !preg_match($alpha_pattern, $first_name) ){
			$flag = false;
		    $error_msg.="First Name must be like eg : Tahir ";
		}
	}

	if ($last_name == "") {
		$flag = false;
		$error_msg.="<li>Please Enter the Last Name !...</li>";
	}else{

		if( !preg_match($alpha_pattern, $last_name) ){
			$flag = false;
		    $error_msg.="<li>Last Name must be like eg : Hingoro !...</li>";
		}
	}

	if ($email == "") {
		$flag = false;
		$error_msg.="<li>Please Enter the Email !...</li>";
	}else{

		if( !preg_match($email_pattern, $email) ){
			$flag = false;
		    $error_msg.="<li>Email must be like eg : tahirali12@gmail.com !...</li>";
		}
	}

	if ($password == "") {
		$flag = false;
		$error_msg.="<li>Please Enter the Password !...</li>";
	}else{

		if( !preg_match($password_pattern, $password) ){
			$flag = false;
		    $error_msg.="<li>Password between 7 to 15 characters one numeric digit and a special character e.g Tahir/1!...</li>";
		}
	}

	if (!isset($gender)) {
		$flag = false;
		    $error_msg.="<li>Please Select Gender !...</li>";
	}

	  if (!preg_match($date_of_birth_pattern, $date_of_birth)) {
        $flag = false;
        $error_msg .= "<li>Please enter a valid Date of Birth (YYYY-MM-DD)!</li>";
      } 



	if ($address == "") {
		$flag = false;
		$error_msg.="<li>Please Enter the Address!...</li>";
	}else{

		if( !preg_match($address_pattern, $address) ){
			$flag = false;
		    $error_msg.="Please Address must be like Hyderabad!...";
		}
	}

	if (!isset($image)) {
		$flag = false;
		    $error_msg.="<li>Please Select Image !...</li>";
	}


	

	if ($flag == false) {
		header("location:Register.php?msg=$error_msg&color=red");
	}

  


    $folder = "User_Image";
    if(!is_dir($folder)){
        if(!mkdir($folder)){
            $message = "Folder Not Created";
            header("location:Register.php?msg=$message&color=red");
            die;
        }
    }
    
    
    $filename   = rand()."_".$_FILES['image']['name'];
    $temp_name  = $_FILES['image']['tmp_name'];
    


   
    move_uploaded_file($temp_name, $folder."/".$filename);

    $current_time = date("Y-m-d g:i:s a");
    $role = 2;
    
    $insertUserQuery = "INSERT INTO user(role_id, first_name, last_name, email, 
    password, gender, date_of_birth, user_image, address, updated_at)
    VALUES(?,?,?,?,?,?,?,?,?,?)";

    $stmt_insert = mysqli_prepare($connection,$insertUserQuery);

    mysqli_stmt_bind_param($stmt_insert,'ssssssssss',$role, $first_name, $last_name, $email, $password,
    $gender, $date_of_birth, $filename,  $address, $current_time);

    
    $msg = "";
    if(mysqli_stmt_execute($stmt_insert))
    {


        $mail = new PHPMailer();
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->Port = 587;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->SMTPAuth = true;
        $mail->Username = 'sameerbaladi9@gmail.com';
        $mail->Password = 'jrbzedbupgmhwfib';
        $mail->setFrom($email, $first_name);
        $mail->addReplyTo($email, 'User');
        // $mail->AddCc($email);
        $mail->addAddress('sameerbaladi9@gmail.com', 'Admin');
        $mail->Subject = 'New User Registration';
        $mail->msgHTML("A new user has registered with the following details:\n\nName: $first_name\nEmail: $email\nPassword: $password");
        $mail->send();

        $mail = new PHPMailer();
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->Port = 587;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->SMTPAuth = true;
        $mail->Username = 'sameerbaladi9@gmail.com';
        $mail->Password = 'jrbzedbupgmhwfib';
        $mail->setFrom('sameerbaladi9@gmail.com', 'Mr Admin');
        $mail->addReplyTo('sameerbaladi9@gmail.com', 'Admin');
        $mail->AddCc('sameerbaladi9@gmail.com');
        $mail->AddBcc('dralih@gmail.com');
        $mail->addAddress($email, $first_name);
        $mail->Subject = 'Registration on the Online Blogging Application Plateform';
        $mail->msgHTML('Please be patient your request has been sent to admin ..');
        $mail->send();
        //mail sent end 

        $userData = array(
            'first_name' => $first_name,
            'last_name' => $last_name,
            'password' => $password,
            'email' => $email,
            'gender' => $gender,
            'date_of_birth' => $date_of_birth,
            'address' => $address,
            'image' => $filename

        );





        $pdf = new FPDF();
        $pdf->AddPage();

        $pdf->SetFont('Arial','B',16);
        $pdf->Cell(0,10,"Registeration Form  ",0,2,'C');
        $pdf->Cell(0,10,'Your Record Mr/Miss:' .$userData['first_name']." ".$userData['last_name'],0,1,'C');
        
        $pdf->SetFont('Arial','',12);
        $pdf->SetDrawColor(230, 0, 0);
        // $pdf->Image($userData['image'],130,30,30,30,'PNG','');
        $pdf->Cell(40,10,'Name:');
        $pdf->Cell(0,10,$userData['first_name']." ".$userData['last_name'],0,1);
        $pdf->Cell(40,10,'Password:');
        $pdf->Cell(0,10,$userData['password'],0,1);

        $pdf->Cell(40,10,'Email:');
        $pdf->Cell(0,10,$userData['email'],0,1);

        $pdf->Cell(40,10,'Gender:');
        $pdf->Cell(0,10,$userData['gender'],0,1);
        $pdf->Cell(40,10,'Date of Birth:');
        $pdf->Cell(0,10,$userData['date_of_birth'],0,1);

        $pdf->Cell(40,10,'Address:');
        $pdf->Cell(0,10,$userData['address'],0,1);


        $pdf->Output("F", $first_name."pdf");




        
        $msg = "User Account Registered";
        header("location: Register.php?msg=$msg&color=green");  

    }
    else
    {
        $msg = "Try Again";
        header("location: Register.php?msg=$msg&color=red");
    }

    



}



?>