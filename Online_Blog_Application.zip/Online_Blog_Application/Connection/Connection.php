<?php

mysqli_report(MYSQLI_REPORT_OFF);
$connection = mysqli_connect('localhost','root','','Shahrukh_Baladi_19658');

if(mysqli_connect_errno()){
    die("Connection Failed");
}



?>