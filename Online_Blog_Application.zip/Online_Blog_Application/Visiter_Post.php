<?php
include_once("Connection/Connection.php");


if (isset($_GET['id'])) {
    $post_id = $_GET['id'];


    $post_query = " SELECT post.`post_id` ,blog.`blog_title`, category.`category_title`, post.`post_title`, post.`post_summary`,post_atachment.`post_attachment_title`, post.`post_description`, post.`featured_image` FROM post 
                    INNER JOIN blog
                    ON post.`blog_id` = blog.`blog_id`
                    INNER JOIN post_category
                    ON post.`post_id` = post_category.`post_id`
                    INNER JOIN category 
                    ON post_category.`category_id` = category.`category_id`
                    INNER JOIN post_atachment
                    ON post.`post_id` = post_atachment.`post_id`
                    WHERE post.`post_id` =".$post_id;
    $result = mysqli_query($connection, $post_query);


     while($post = mysqli_fetch_assoc($result)){
    

        ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Blog Application</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="Css/Home_2.css">

</head>
<body>
<?php

    include_once("NavBar/navbar.php");
    ?>
    <script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>


    <div class="container">
        <div class="row">
            <div class="col-12">
               <div class="card m-4">
                    <img src="Admin_panel/Post/Post_Image/<?php echo $post["featured_image"];?>" class="card-img-top" alt="cover" height="500" width="100">
               </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12 ms-4 me-4 text-primary">
                <h2><?php echo $post["post_title"];?></h2>

            </div>

        </div>
        
        <div class="row">
            <div class="col-12 ps-5 pe-5 text-center">
                <p><?php echo $post["post_summary"];?></p>
            </div>
        </div>
        
        <div class="row">
            <div class="col-12 ps-5 pe-5" style="text-align: justify;">
                <h2>Description</h2>
                <p><?php echo $post["post_description"];?>
                </p>

                
                <?php
                    $attachment = "SELECT * FROM post_atachment INNER JOIN post ON post_atachment.`post_id` = post.`post_id`
                        WHERE post.`post_id` =".$post_id;
                    $result = mysqli_query($connection, $attachment);
?>


                   
                <h3 class="text-center"><?php echo $post["post_attachment_title"];?></h3>
                
               

                
                    <div class="row"> 
                        <div class="card-group  col-12 h-100">
                          <?php
                             if(mysqli_num_rows($result)>0){
                                while($attach = mysqli_fetch_assoc($result)){
                            ?>
                            <div class="col-4 ">
                                    <img src="Admin_panel/Post/Post_Attachment_Image/<?php echo $attach["post_attachment_path"];?>" class="h-100 p-3 rounded " style=" width: 100%;
                                            float: left;">
                            </div>

                            <?php
                    }
                }
                ?>
                        </div>
                    </div>
                
               
               
            </div>
            

        </div>


    </div>
     

  
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <?php include_once("footer.php");?>
            </div>
        </div>
    </div>
  
            
        
    
</body>
</html>

<?php
    }

}
?>