<?php

require_once("Connection/Connection.php");
require_once('Session.php');

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registration</title>
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="Css/Register.css">
  <style type="text/css">
    span {
      color: red;
    }

    li {
      color: red;
      list-style: none;
    }
  </style>


  <script type="text/javascript">
    function register_form() {



      var alpha_pattern = /^[A-Z]{1}[a-z]{2,}$/;
      var email_pattern = /^[A-Za-z]{2,20}[@][a-z]{5,8}[.][a-z]{2,5}$/;
      var password_pattern = /^[A-Za-z]\w{7,14}$/;
      var address_pattern = /^[A-z]{4,20}/;

      var first_name = document.getElementById("first_name").value;
      var last_name = document.getElementById("last_name").value;
      var email = document.getElementById("email").value;
      var gender = null;
      var male = document.getElementById("gender_male");
      var female = document.getElementById("gender_female");
      var address = document.getElementById("Address").value;
      var date_of_birth = document.getElementById("dob").value;
      var password = document.getElementById("Password").value;
      var image = document.getElementById("profile_pic").value;



      if (male.checked) {
        gender = male.value;

      } else if (female.checked) {
        gender = female.value;

      }

      if (date_of_birth.selected) {
        date_of_birth = date_of_birth.selected;

      }

      if (image.selected) {
        image = image.selected;

      }


      var flag = true;


      if (first_name == "") {
        flag = false;
        document.getElementById("first_name_msg").innerHTML = "Please Enter First Name !...";
      } else {
        document.getElementById("first_name_msg").innerHTML = "";

        if (alpha_pattern.test(first_name) == false) {
          flag = false;
          document.getElementById("first_name_msg").innerHTML = " First Name must be like: Ali";
        }
      }

      if (last_name == "") {
        flag = false;
        document.getElementById("last_name_msg").innerHTML = "Please Enter Last Name !...";
      } else {
        document.getElementById("last_name_msg").innerHTML = "";

        if (alpha_pattern.test(last_name) == false) {
          flag = false;
          document.getElementById("last_name_msg").innerHTML = " Last Name must be like: Khan";
        }
      }

      if (email == "") {
        flag = false;
        document.getElementById("email_msg").innerHTML = "Please Enter Email !...";
      } else {
        document.getElementById("email_msg").innerHTML = "";

        if (email_pattern.test(email) == false) {
          flag = false;
          document.getElementById("email_msg").innerHTML = " Email must be like eg: shery@gmail.com";
        }
      }
      if (password == "") {
        flag = false;
        document.getElementById("password_msg").innerHTML = "Please Enter Password !...";
      } else {
        document.getElementById("password_msg").innerHTML = "";

        if (password_pattern.test(password) == false) {
          flag = false;
          document.getElementById("password_msg").innerHTML = " Password must be like : Ali12";
        }
      }
      if (!gender) {

        flag = false;
        document.getElementById("gender_msg").innerHTML = "Please Select Gender !...";
      } else {
        document.getElementById("gender_msg").innerHTML = "";
      }


      if (address == "") {
        flag = false;
        document.getElementById("address_msg").innerHTML = "Please Enter Address";
      } else {
        document.getElementById("address_msg").innerHTML = "";

        if (address.test(address) == false) {
          flag = false;
          document.getElementById("address_msg").innerHTML = " Address Must be like Jamshoro, Sindh";
        }
      }

      if (!date_of_birth) {

        flag = false;
        document.getElementById("date_msg").innerHTML = "Please Select Date Of Birth !...";
      } else {
        document.getElementById("date_msg").innerHTML = "";
      }



      if (!image) {

        flag = false;
        document.getElementById("image_msg").innerHTML = "Please Select An Image !...";
      } else {
        document.getElementById("image_msg").innerHTML = "";
      }




      if (flag) {
        return true;
      } else {
        return false;

      }


    }
  </script>

</head>

<body>

  <?php
  include_once("NavBar/navbar.php");


  $getRolesQuery = "SELECT * FROM `role`";
  $result = mysqli_query($connection, $getRolesQuery);


  ?>
  <div class="container mt-3 mb-3">
    <div class="row" style="display: flex;">

      <div class="col-8 mx-auto">
        <form action="Register_process.php" method="POST" enctype="multipart/form-data">
          <h5 class="fw-normal mb-3 pb-3 text-center">Registration Form</h5>

          <div class="image">

            <div class="row">
              <div class="col-12 text-center fw-bold text-white">
                <?php
                if (isset($_GET['msg'])) {
                ?>
                  <div class="alert alert-success" role="alert">
                    <?php echo $_GET['msg']; ?>
                  </div>

                 
                <?php
                }

                ?>

              </div>

            </div>




            <div class="row">
              <div class="form-outline mb-1 col-6">
                <label class="form-label" for="form2Example17">First Name</label>
                <input type="text" id="first_name" class="form-control form-control-lg" name="first_name" placeholder="First Name" />
                <span id="first_name_msg"></span>

              </div>
              <div class="form-outline mb-1 col-6">
                <label class="form-label" for="form2Example17">Last Name</label>
                <input type="text" id="last_name" class="form-control form-control-lg" name="last_name" placeholder="Last Name" />
                <span id="last_name_msg"></span>
              </div>
            </div>


            <div class="form-outline mb-1">
              <label class="form-label" for="form2Example27">Email</label>
              <input type="email" id="email" class="form-control form-control-lg" name="email" placeholder="Email" />
              <span id="email_msg"></span>
            </div>
            <div class="row">
              <label>Gender:</label>
              <div class="col-6">
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="gender" id="gender_male" value="Male">
                  <label class="form-check-label">
                    Male
                  </label>
                </div>
              </div>
              <div class="col-6">
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="gender" id="gender_female" value="Female">
                  <label class="form-check-label">
                    Female
                  </label>
                </div>
              </div>
              <span id="gender_msg"></span>
            </div>
            <div class="row">
              <div class="form-outline mb-1 col-12">
                <label class="form-label" for="form2Example17">Date Of Birth:</label>
                <input type="Date" id="dob" name="date_of_birth" class="form-control form-control-lg" />
                <span id="date_msg"></span>
              </div>

            </div>
            <div class="col-12">
              <label class="form-label" for="form2Example27">Address</label>
              <textarea name="address" id="Address" cols="30" rows="3"></textarea>
              <span id="address_msg"></span>

            </div>
            <div class="form-outline mb-1">
              <label class="form-label" for="form2Example27">Password</label>
              <input type="Password" id="Password" name="password" class="form-control form-control-lg" placeholder="Password" />
              <span id="password_msg"></span>

            </div>
            <div class="form-outline mb-1 col-12">
              <label class="form-label" for="form2Example17">Select In Image:</label>
              <input type="file" name="image" class="form-control form-control-lg" id="profile_pic">
              <span id="image_msg"></span>


            </div>
            <div class="row align-items-center pt-1 mt-2 mb-1">
              <div class="col-12 ">
                <input class="btn btn-lg btn-block" style="background-color: #424874;" type="submit" value="Register" name="Register" onclick="return register_form()">
              </div>
            </div>

            <div class="row">
              <div class="register-account">
                <a href="Login.php">Already Registered! Login Here</a>
              </div>
            </div>
        </form>

      </div>
    </div>
  </div>





</body>

</html>