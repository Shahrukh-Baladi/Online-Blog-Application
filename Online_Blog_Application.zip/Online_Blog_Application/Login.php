<?php

require_once("Connection/Connection.php");
require_once('Session.php');




?>

<!DOCTYPE html>
<html>

<head>
  <title>Login Form</title>
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  
  <script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>
  

</head>

<body>
  <?php
  include_once("NavBar/navbar.php");
  ?>



  <section class="vh-100">
    <div class="container">
      <div class="row m-3">
        <div class="col-6 text-black shadow mx-auto" style="height: 100vh">

          <div>

            <form action="Login_process.php" method="POST" class="mt-2 ms-3 me-3">

              <h2 class="fw-normal text-center mt-2 mb-3 pb-3" style="letter-spacing: 1px;">Login</h2>

              <div class="row">
                <div class="col-12 text-center fw-bold">

                  <div class="text-center">
                    <?php
                    if (isset($_GET['msg'])) {
                    ?>
                      <div class="alert alert-primary" role="alert">
                        <?php echo $_GET['msg']; ?>
                      </div>
                    <?php
                    }

                    ?>
                  </div>
                </div>

              </div>

              <div class="form-outline mb-4">
                <label class="form-label" for="form2Example18">Email</label>
                <input type="email" id="form2Example18" class="form-control form-control-lg" name="email" />
              </div>

              <div class="form-outline mb-4">
                <label class="form-label" for="form2Example28">Password</label>
                <input type="password" id="form2Example28" class="form-control form-control-lg" name="password" />
              </div>

              <div class="pt-1 mb-4">

                <input class="btn btn-lg btn-block col-12 text-light" style="background-color: #424874;" type="submit" value="Login" name="Login">

              </div>

              <p class="text-center"><a class="text-muted text-dark" href="forget_password.php">Forgot password?</a></p>
              <p class="text-center">Don't have an account? <a href="Register.php" class="link-info ">Register here</a></p>

            </form>

          </div>

        </div>

      </div>
    </div>
  </section>
</body>

</html>