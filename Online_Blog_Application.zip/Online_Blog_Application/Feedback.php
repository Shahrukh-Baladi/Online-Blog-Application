<?php

 	require_once("Connection/Connection.php");
    date_default_timezone_set("Asia/karachi");



    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    require 'PHPMailer/src/PHPMailer.php';
    require 'PHPMailer/src/SMTP.php';
    require 'PHPMailer/src/Exception.php';


if(isset($_POST['Submit']))
{
     
    $username = $_POST['name'];
    $user_email=$_POST['email'];
	$message =$_POST['feedback'];
    $current_time = date("Y-m-d g:i:s a");
   
    
    $insertUserQuery = "INSERT INTO user_feedback(user_name, user_email, feedback, updated_at)
    VALUES('".$username."', '".$user_email."', '".$message."','".$current_time."')";
    $result  = mysqli_query($connection, $insertUserQuery);"";


    
    if($result)
    {
    	$mail = new PHPMailer();
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->Port = 587;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->SMTPAuth = true;
        $mail->Username = 'sameerbaladi9@gmail.com';
        $mail->Password = 'jrbzedbupgmhwfib';
        $mail->setFrom($email, $first_name);
        $mail->addReplyTo($email, 'User');
        // $mail->AddCc($email);
        $mail->addAddress('sameerbaladi9@gmail.com', 'Admin');
        $mail->Subject = 'User Feedback';
        $mail->msgHTML("User Has Given A Feedback:\n\nName: $username \n Email: $user_email \n message: $$message");
        $mail->send();

        $msg = "feedback Sent";
        header("location: Contact.php?msg=$msg&color=green");  

    }
    else
    {
        $msg = "Try Again";
        header("location: Contact.php?msg=$msg&color=red");
    }

}







?>