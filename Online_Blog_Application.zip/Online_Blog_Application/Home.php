<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Blog Application</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="Css/Home.css">
    <script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>

</head>
<body>
<?php
  require_once("Connection/Connection.php");

    include_once("NavBar/navbar.php");

      ?>

  <div class="container">
    <div class="row">

        <?php
            $blog_slider = " SELECT * FROM blog WHERE blog_status ='Active'
                 LIMIT 3;
                ";
            $result = mysqli_query($connection, $blog_slider);
   
            while($blog_data = mysqli_fetch_assoc($result)){



    ?>
    <div class="col-4 p-2  ">
    <div class="card  shadow"  style="height: 100%;">
      <img src="Admin_panel/Blog/Blog_Image/<?php echo $blog_data["blog_background_image"];?>" alt="" class="card-img-top"  style="height: 80%;" >
      <div class="card-body">
        <h5 class="card-title"><?php echo $blog_data["blog_title"];?></h5>
        <a href="Show_blog.php?id=<?php echo $blog_data['blog_id']; ?>" class="btn btn-outline-success btn-sm">View Blog</a>
        
      </div>
     </div>
    </div>
     <?php
      }?>
  </div>
</div>


      <?php

    $totalCountPosts = "SELECT COUNT(*) AS 'Total_Posts' FROM `post` ";
    $getResultCountPosts = mysqli_query($connection,$totalCountPosts);
    $Total_Posts = mysqli_fetch_assoc($getResultCountPosts);


    $per_page = 4;

    $total_links = ceil($Total_Posts['Total_Posts']/$per_page);


    
    if(isset($_GET['page']))
    { 
      $start = ($_GET['page']*$per_page);
    }else
    {
      $start = 0;
      $_GET['page'] = 0;
    }




  



              
    ?>


  
    <!-- Post Starts -->

    
    <div class="container">
      <div class="row">
      
    </div>
      <div class="row p-4">
    <div class="col-8">
      <div class="col-12 bg-dark text-light rounded ps-2">
        <h2>Featured Posts</h2>
      </div>
    <?php
    $Show_post = "SELECT p.`post_id`, blog.`blog_title`,p.`post_title`, p.`post_summary`, p.`post_description`, p.`featured_image`, category.`category_title`, p.`post_status`,p.`is_comment_allowed`, p.`created_at`,p.`updated_at` FROM post p
                INNER JOIN blog
                ON p.`blog_id` = blog.`blog_id`
                INNER JOIN post_category
                ON p.`post_id`= post_category.`post_id`
                INNER JOIN category
                ON category.`category_id` = post_category.`category_id`
                WHERE blog.`blog_status` = 'Active'
                ORDER BY p.`post_id` DESC
                LIMIT $start,$per_page;
                            ";

                $result = mysqli_query($connection, $Show_post);

                if(mysqli_num_rows($result)>0){

                    while($post = mysqli_fetch_assoc($result)){

    ?>
    
    
          
          <div class="card mb-3">
            <img src="Admin_panel/Post/Post_Image/<?php echo $post["featured_image"];?>" class="card-img-top" alt="...">
            <hr>
            <div class="card-body shadow-sm">
              <h5 class="card-title"><b class="text-primary"><?php echo $post["blog_title"];?></b> / <b class="text-danger"><?php echo $post["category_title"];?></b></h5>
              <h5 class="card-title pt-2 pb-2 ms-1 text-success"><?php echo $post["post_title"];?></h5>
              <p class="card-text ms-1"><?php echo $post["post_summary"];?></p>
              <a href="User_panel/User_Post.php?id=<?php echo $post['post_id']; ?>" class="btn btn-outline-success btn-sm m-3 ">Read More</a>
            </div>
          </div>
            
             <?php
  }
}

    ?>
    </div>
        
          <div class="col-4 ">
            <div class="card mb-2 text-light bg-dark">
              <h4 class="text-center " >Recent Post</h4>
              
            </div>
    <?php
    $Show_post = "  SELECT p.`post_id`, blog.`blog_title`,p.`post_title`, p.`post_summary`, p.`post_description`, p.`featured_image`, category.`category_title`, p.`post_status`,p.`is_comment_allowed`, p.`created_at`,p.`updated_at` FROM post p
                    INNER JOIN blog
                    ON p.`blog_id` = blog.`blog_id`
                    INNER JOIN post_category
                    ON p.`post_id`= post_category.`post_id`
                    INNER JOIN category
                    ON category.`category_id` = post_category.`category_id`
                    WHERE blog.`blog_status` = 'Active'
                    ORDER BY p.`post_id` DESC
                                LIMIT 3;
                            ";

                $result = mysqli_query($connection, $Show_post);

                if(mysqli_num_rows($result)>0){
                    while($post = mysqli_fetch_assoc($result)){

    ?>
    
    
          
          <div class="card mb-3">
            <img src="Admin_panel/Post/Post_Image/<?php echo $post["featured_image"];?>"  class="  card-img-top" alt="PostImage"  style="height: auto;">
            <hr>
            <div class="card-body shadow-sm">
             
              <h5 class="card-title pt-1 pb-1 ms-1 "><?php echo $post["post_title"];?></h5>
              <p class="card-text ms-1"><?php echo $post["post_summary"];?></p>
              <a href="../User_panel/User_Post.php?id=<?php echo $post['post_id']; ?>" class="btn btn-outline-success btn-sm m-3 ">Read More</a>
            </div>
          </div>
            
             <?php
  }
}

    ?>
    </div>
      </div>
 
    
  </div>
  <div class="row"> 
   <nav aria-label="Page navigation example">
      <ul class="pagination justify-content-center">

    <?php 
        if($_GET['page'] > 0)
        {
          ?>
  
        <li class="page-item">
            <a class="page-link" href="Home.php?page=<?php echo $_GET['page'] - 1; ?>">
              Previous
            </a>
        </li>
           <?php 

        }
      
      for($i=1; $i<=$total_links; $i++)
      {
        if($_GET['page'] == $i-1)
        {
          ?>
          <li class="page-item">
            <a class="page-link" href="Home.php?page=<?php echo $i-1;?>" style="font-size: 30px; color: red;">
              <?php echo $i; ?>
            </a>
          </li>
          <?php

        }else{
          ?>
          <li class="page-item">
            <a class="page-link" href="Home.php?page=<?php echo $i-1;?>">
              <?php echo $i; ?>
            </a>
        </li>
          <?php
        }
        
      }
      //echo $i;
      if(( 1 + $_GET['page']) != $i-1)
      {
        ?>
      <li class="page-item">
        <a class="page-link" href="Home.php?page=<?php echo $_GET['page'] + 1; ?>">
          Next
        </a>
      </li>
        <?php
      }
      

      



    ?>   



      </ul>
    </nav>

   
            
         </div>
      



	<?php include_once("footer.php");?>
    		
    	
    
</body>
</html>
