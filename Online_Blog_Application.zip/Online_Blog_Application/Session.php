<?php 
	
	session_start();
	if(isset($_SESSION['user']) && $_SESSION['user']['role_id'] == 1)
	{
		header("location: Admin_panel/Home.php");
	}
	elseif(isset($_SESSION['user']) && $_SESSION['user']['role_id'] == 2)
	{
		header("location: User_panel/Home.php");
	}


?>