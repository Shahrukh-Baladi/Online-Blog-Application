<?php

session_start();

?>
<!DOCTYPE html>
<html>
<head>
	<title>About Us</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <script type="text/javascript" src="../bootstrap/js/bootstrap.bundle.min.js"></script>


</head>
<body>
<?php
    include_once("NavBar/navbar.php");
    ?>
    <div class="container">
    <div class="card m-3 shadow">
        <div class="row">
            <div class="col-4">
                <img src="../Image/slider2.jpg" class="img-fluid" alt="About Us">
            </div>
            <div class="col-8">
                <div class="card-body">
                    <h4 class="card-title fw-bold text-center">About US</h4>
                    <p class="card-text">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente, voluptate soluta rem, aspernatur libero atque qui nemo nulla unde, suscipit adipisci voluptates asperiores et perferendis consequuntur sunt sint necessitatibus. Qui! Lorem ipsum dolor sit amet consectetur adipisicing elit. Velit, provident quam error at itaque totam dolore molestias dolores neque facere suscipit, nisi expedita ad porro ipsa culpa assumenda iste sapiente.
                    Exercitationem nihil architecto error quasi, pariatur eos iure iusto possimus cumque odio eligendi aliquid doloremque totam voluptatem nisi perferendis debitis voluptas aliquam officia, in ea, tempore optio officiis. Deserunt, laboriosam.</p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Vero officiis, necessitatibus, accusamus enim aliquid, optio aperiam porro quod blanditiis similique culpa atque dolores sunt minima modi qui ut consectetur? Maiores!
                    <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis laudantium esse reprehenderit tempora voluptate eum facilis numquam rem voluptatem quae vel, illo amet hic quisquam assumenda nihil beatae. Quisquam, nam?
                    </p>
                     <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis laudantium esse reprehenderit tempora voluptate eum facilis numquam rem voluptatem quae vel, illo amet hic quisquam assumenda nihil beatae. Quisquam, nam?
                    </p>
                </div>
            </div>
        </div>
    </div>

    </div>

    <?php
    include_once("../footer.php");
    ?>
    <script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>