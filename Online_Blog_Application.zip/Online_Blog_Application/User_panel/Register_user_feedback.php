<?php
    
 	require_once("../Connection/Connection.php");
    date_default_timezone_set("Asia/karachi");
            include_once("Session_User.php");

if(isset($_POST['submit']))

{
    $user_id = $_SESSION['user']['user_id'];

    $username = $_SESSION['user']['first_name']." ".$_SESSION['user']['last_name'];
    
    $user_email = $_SESSION['user']['email'];




     
    
    
	$message =$_POST['message'];
    $current_time = date("Y-m-d g:i:s a");
   
    
    $insert_user_feedback = "INSERT INTO user_feedback(user_id, user_name, user_email, feedback, updated_at)
    VALUES('".$user_id."','".$username."','".$user_email."','".$message."','".$current_time."')";
    

    $result  = mysqli_query($connection, $insert_user_feedback);
    
    $msg = "";
    if($result)
    {

        $msg = "feedback Sent";
        header("location: Contact.php?msg=$msg&color=green");  

    }
    else
    {
        $msg = "Try Again";
        header("location: Contact.php?msg=$msg&color=red");
    }

}







?>