<?php
include_once("../Connection/Connection.php");
include_once("Session_User.php");


if (isset($_POST['post_comment'])) {
    $ID = $_POST['post'];
    $user_id = $_SESSION['user']['user_id'];
    $comment = $_POST['comment'];
    $status = 'InActive';
    

    $insert = "INSERT INTO post_comment(post_id, user_id, comment, is_active)
            VALUES('".$ID."', '".$user_id."',  '".$comment."', '".$status."')";
    $result = mysqli_query($connection, $insert);

    

    if($result){
        $msg = "Comment Submitted";
    header("location: User_Post.php?id=".$ID."&msg=$msg&color=green");

    }
    else
    {
        $msg = "Failed";
        header("location: User_Post.php?id=".$ID."&msg=$msg&color=red");
    }
    
}










        ?>