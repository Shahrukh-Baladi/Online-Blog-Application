<?php 
            require_once("../Connection/Connection.php");
            // require_once 'Session_maintance.php';

            $getQuery = "SELECT * FROM `category` WHERE category_status = 'Active';";
            $result = mysqli_query($connection,$getQuery);

            $getQuery = "
                 SELECT * FROM `blog` WHERE blog_status = 'Active';";
            $result_blog = mysqli_query($connection,$getQuery);


        ?>


<nav class="navbar navbar-expand-lg " style="background-color: #424874;">
        <div class="container-fluid">
            <a class="navbar-brand text-white" href="#">Online Blog Application</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarScroll">
                <ul class="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll" style="--bs-scroll-height: 100px;">
                    <li class="nav-item">
                        <a class="nav-link active text-white" aria-current="page" href="User.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav nav-link text-white" href="Contact.php">Feedback</a>
                    </li>
                    
                 <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Categories
                        </a>
                        <ul class="dropdown-menu bg-success bg-gradient text-white">
                        <?php 
                                    while ($row = mysqli_fetch_assoc($result)) 
                                    {
                                        ?>
                                        <li>
                                            <a class="dropdown-item text-light" href="Show_category.php?id=<?php echo $row['category_id']; ?>" >
                                            <?php echo $row['category_title']; ?>
                                        </a></li>
                    
                                        <?php   
                                    }

                                ?>
                        </ul>
                    </li>
                      
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Blogs
                        </a>
                        <ul class="dropdown-menu bg-success bg-gradient text-white">
                        <?php 
                                    while ($row = mysqli_fetch_assoc($result_blog)) 
                                    {
                                        ?><li>
                                            <a class="dropdown-item text-light" href="Show_blog.php?id=<?php echo $row['blog_id']; ?>" >
                                            <?php echo $row['blog_title']; ?>
                                        </a></li>
                    
                                        <?php   
                                    }

                                ?>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="About.php">About Us</a>
                    </li>
                </ul>
                
            </div>
            <form class="d-flex h-10" role="profile">
               
               
                <a href="Profile.php">
                    <h5 class="text-white btn btn-outline-light text-center me-1">
                        
                        <?php 
                            echo $_SESSION['user']['first_name']." ".$_SESSION['user']['last_name'];
                        ?>
                    </h5>
                </a>
                <a href="../Logout.php">
                    <h5 class="text-white btn btn-outline-light text-center"  >Logout</h5>
                </a>
            </form>
        </div>
    </nav>