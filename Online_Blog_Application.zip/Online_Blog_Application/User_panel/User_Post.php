<?php
include_once("../Connection/Connection.php");


if (isset($_GET['id'])) {
    $post_id = $_GET['id'];


    $post_query = " SELECT post.`post_id` ,blog.`blog_title`, category.`category_title`, post.`post_title`, post.`post_summary`,post_atachment.`post_attachment_title`, post.`post_description`, post.`featured_image` FROM post 
                    INNER JOIN blog
                    ON post.`blog_id` = blog.`blog_id`
                    INNER JOIN post_category
                    ON post.`post_id` = post_category.`post_id`
                    INNER JOIN category 
                    ON post_category.`category_id` = category.`category_id`
                    INNER JOIN post_atachment
                    ON post.`post_id` = post_atachment.`post_id`
                    WHERE post.`post_id` =".$post_id;
    $result = mysqli_query($connection, $post_query);


     while($post = mysqli_fetch_assoc($result)){
    

        ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Blog Application</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../Css/Home_2.css">

</head>
<body>
<?php

    include_once("Session_User.php");
    include_once("NavBar/navbar.php");
    ?>
    <script type="text/javascript" src="../bootstrap/js/bootstrap.bundle.min.js"></script>


    <div class="container">
        <div class="row">
            <div class="col-12">
               <div class="card m-4">
                    <img src="../Admin_panel/Post/Post_Image/<?php echo $post["featured_image"];?>" class="card-img-top" alt="cover" height="500" width="100">
               </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12 ms-4 me-4 text-primary">
                <h2><?php echo $post["post_title"];?></h2>

            </div>

        </div>
        
        <div class="row">
            <div class="col-12 ps-5 pe-5 text-center">
                <p><?php echo $post["post_summary"];?></p>
            </div>
        </div>
        
        <div class="row">
            <div class="col-12 ps-5 pe-5" style="text-align: justify;">
                <h2>Description</h2>
                <p><?php echo $post["post_description"];?>
                </p>

                
                <?php
                    $attachment = "SELECT * FROM post_atachment INNER JOIN post ON post_atachment.`post_id` = post.`post_id`
                        WHERE post.`post_id` =".$post_id;
                    $result = mysqli_query($connection, $attachment);
?>


                   
                <h3 class="text-center"><?php echo $post["post_attachment_title"];?></h3>
                
               

                
                    <div class="row"> 
                        <div class="card-group  col-12 h-100">
                          <?php
                             if(mysqli_num_rows($result)>0){
                                while($attach = mysqli_fetch_assoc($result)){
                            ?>
                            <div class="col-4 ">
                                    <img src="../Admin_panel/Post/Post_Attachment_Image/<?php echo $attach["post_attachment_path"];?>" class="h-100 p-3 rounded " style=" width: 100%;
                                            float: left;">
                            </div>

                            <?php
                    }
                }
                ?>
                        </div>
                    </div>
                
               
               
            </div>
            

        </div>


    </div>
     <div class="container my-5 py-5">
    <div class="row d-flex justify-content-center">
      <div class="col-md-12 col-lg-10 col-xl-8">
        <div class="card">
          <div class="card-body">
            <?php
                $post_comment_query = "
                
                SELECT post_comment.*, post.`post_id`, post.`post_title`, user.`first_name`, user.`last_name`, user.`user_image` 
                FROM post_comment 
                INNER JOIN USER
                ON post_comment.`user_id` = user.`user_id`
                INNER JOIN post
                ON post_comment.`post_id` = post.`post_id`
                WHERE post_comment.`is_active` = 'Active' AND post.`post_id` =".$post_id;
                $result = mysqli_query($connection, $post_comment_query);
                while($post_comment = mysqli_fetch_assoc($result)){
              ?>
            <div class="d-flex flex-start align-items-center">
              
              <img class="rounded-circle shadow-1-strong me-3"
                src="../User_Image/<?php echo $post_comment["user_image"];?>" alt="avatar" width="60"
                height="60" />
              <div>
                <h6 class="fw-bold text-primary mb-1"><?php echo $post_comment["first_name"]." ".$post_comment['last_name'];?></h6>
                <p class="text-muted small mb-0">
                    <?php echo $post_comment["created_at"];?>
                </p>
              </div>

            </div>

              <div class="bg-light text-dark ps-5 ms-5">
                <p class="m-3">
              <?php echo $post_comment["comment"];?>
            </p>
                
              </div>
            <?php
                }
              ?>
          
          </div>
            <form action="Comment_process.php" method="POST">
                <div class="text-center text-white">
                  <span id="msg">
                      <?php 
                    if(isset($_GET['msg']))
                    {
                      ?>
                        <p class="alert alert-primary" role="alert">
                          
                          <?php echo $_GET['msg']; ?>
                        </p>
                      <?php
                    }

                  ?>

                  <script type="text/javascript">
                    setTimeout(function(){
                     document.getElementById('msg').innerHtml = '';
                    },1000);
                  
                  </script>
                  
                  </span>
              </div> 
                 <div class="card-footer border-0" style="background-color: #f8f9fa;">
                       
                    <div class="d-flex flex-start w-100 ">
                  <input type="hidden" name="post" value="<?php echo $post['post_id']; ?>">
                      
                      <div class="form-outline w-100">
                        <textarea class="form-control" id="textAreaExample" name="comment" rows="4"
                          style="background: #fff;"></textarea>
                      </div>
                    </div>
                    <div class="float-end m-2 p-1">
                      <input type="submit" name="post_comment" value="Post comment" class="btn btn-primary btn-sm">
                      <input type="reset" value="Cancel" class="btn btn-light text-dark btn-sm" >
                    </div>
                  </div>
            </form>
        </div>
      </div>
    </div>
  </div>

   

  
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <?php include_once("../footer.php");?>
        </div>
      </div>
    </div>
  
        
      
    
</body>
</html>

<?php
    }

}
?>