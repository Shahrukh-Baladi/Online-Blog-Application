<?php
include_once("Connection/Connection.php");

if (isset($_GET['id'])) {
    $category_id = $_GET['id'];


   

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Blog Application</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="Css/Home_2.css">
    <script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>


</head>
<body>
<?php

    include_once("NavBar/navbar.php");
    ?>
    <script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>

    <?php
      $category_show = " SELECT * FROM category WHERE category_id =".$category_id;
         $result = mysqli_query($connection, $category_show);

               
                while($category_data = mysqli_fetch_assoc($result)){



    ?>

      <div class="card">
        <div class="card-header text-center fw-bold"><?php echo $category_data["category_title"];?></div>
        <div class="card-body">
          <blockquote class="blockquote mb-0 mt-2">
            
            <footer class="blockquote-footer text-center">
              <?php echo $category_data["category_description"];?>
              
            </footer>
          </blockquote>
        </div>
      </div>

    <?php

  }
       

    ?>

    
     
      <div class="container">
         <div class="row  m-2 row-cols-1 row-cols-md-3 g-4">
          <?php
            $category_query = "    SELECT  category.*, post.`post_title`, post.`post_summary`,post.`post_id`, post.`post_description`, post.`featured_image`  FROM category 
                    INNER JOIN post_category
                    ON category.`category_id` = post_category.`category_id`
                    INNER JOIN post
                    ON post_category.`post_id` = post.`post_id`
                    WHERE category.`category_id` = ".$category_id;
                  
                    $result = mysqli_query($connection, $category_query);

               
                while($category = mysqli_fetch_assoc($result)){

          ?>
          <div class="col">
            <div class="card h-100">
              <img src="../Admin_panel/Post/Post_Image/<?php echo $category['featured_image'];?>" class="card-img-top " style="height: 80%;" alt="category image"/>
              <div class="card-body">
                <h5 class="card-title"><?php echo $category["post_title"];?></h5>
                <p class="card-text">
                  <?php echo $category["post_summary"];?>
                </p>
              <a href="Visiter_Post.php?id=<?php echo $category['post_id']; ?>"
                                   class="btn btn-primary btn-sm">Read More</a>
              </div>
            </div>
          </div>
           <?php
            }
      ?>
        </div>
      </div>
     

      <?php
          include_once("footer.php");


      ?>

    <script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>

      
</body>
</html>

<?php


}
?>
