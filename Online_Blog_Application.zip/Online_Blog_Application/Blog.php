<?php
include_once("Connection/Connection.php");

if (isset($_GET['id'])) {
    $blog_id = $_GET['id'];


   

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Blog Application</title>
    <link rel="stylesheet" href="Css/Home_2.css">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>


</head>
<body>
<?php

    include_once("NavBar/navbar.php");
    ?>
    <script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>

    <div class="container">
      <div class="row mt-2 h-50">
        <?php
          $All_blogs = "SELECT b.*, u.* FROM blog b
                 INNER JOIN USER u
                 ON b.`user_id` = u.`user_id`
                 WHERE b.`blog_id` =".$blog_id;

          $result = mysqli_query($connection, $All_blogs);

               
          while($blog_data = mysqli_fetch_assoc($result)){

        ?>

        <div class="col-12 ">
          <div class="card ">
            <img src="Admin_panel/Blog/Blog_Image/<?php echo $blog_data['blog_background_image'];?>" class="card-img-top" alt="..." style="height: 80%;">
              <div class="card-body">
                <div class="row">
                    <div class="col-12">

                        <h5 class="card-title text-center"><?php echo $blog_data["blog_title"];?></h5>
                      
                    </div>
                    <div class="row">
                     <div class="col text-center">
                       <img src="User_Image/<?php echo $blog_data["user_image"]; ?>" alt="Profile Image" style="width: 45px; height: 45px"
                                     class="rounded-circle">
                       <p class="card-text"><?php echo $blog_data["first_name"]." ".$blog_data["last_name"];?></p> 

                      
                     </div>
                      
                    </div>
                    
                </div>
              </div>
            </div>
        </div>
        <?php
      }

      ?>
      </div>
      
    </div>


    <div class="container"> 
        <div class="row m-2 row-cols-1 row-cols-md-3 g-4">
          <?php 
        $blog_query = "   
            SELECT  post.*, blog.*  FROM blog
            INNER JOIN post
            ON blog.`blog_id` = post.`blog_id`
            WHERE blog.`blog_id` = ".$blog_id;
                  
                    $result = mysqli_query($connection, $blog_query);

               
                while($blog_post = mysqli_fetch_assoc($result)){

      ?>
      <div class="col">
            <div class="card h-100">
              <img src="Admin_panel/Post/Post_Image/<?php echo $blog_post['featured_image'];?>" class="card-img-top " style="height: 80%;" alt="post image"/>
              <div class="card-body">
                <h5 class="card-title"><?php echo $blog_post["post_title"];?></h5>
                <p class="card-text">
                  <?php echo $blog_post["post_summary"];?>
                </p>
              <a href="Visiter_Post.php?id=<?php echo $blog_post['post_id']; ?>"
                                   class="btn btn-primary btn-sm">Read More</a>
              </div>
            </div>
          </div>
        <?php } ?>
          
        </div>
    </div>

      <?php
          include_once("footer.php");


      ?>

    <script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>

      
</body>
</html>

<?php


}
?>
