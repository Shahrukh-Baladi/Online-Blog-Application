<?php
include_once("../../Connection/Connection.php");
include_once("../Session_Admin.php");

if (isset($_GET['id'])) {
    $blog_id = $_GET['id'];


    $blog_query = "SELECT * FROM blog WHERE blog_id = ".$blog_id;
    $result = mysqli_query($connection, $blog_query);

    if (mysqli_num_rows($result) > 0) {
        $blog = mysqli_fetch_assoc($result);
    

        ?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update User</title>
    <link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../Css/Home.css">
    <link rel="stylesheet" type="text/css" href="../../Css/sidebar.css">

</head>
<body>
<?php
    include_once("../NavBar/navbar.php");

?>
<div class="container-fluid">
    <div class="row">
        <?php
        include_once("../Sidebar/sidebar.php");
        ?>
        <div class="col-10 p-2">
            <h3 class="text-center">Update Blog</h3>
            <form method="post" action="../Process/update_process.php" enctype="multipart/form-data">
                <input type="hidden" name="blog_id" value="<?php echo $blog['blog_id']; ?>">
                <div class="mb-3">
                    <label for="first_name" class="form-label">Title</label>
                    <input type="text" class="form-control" id="blog_title" name="title" value="<?php echo $blog['blog_title']; ?>" required>
                </div>
                <div class="mb-3">
                    <label for="last_name" class="form-label">Post Per Page</label>
                    <input type="text" class="form-control" id="post_number" name="post_per_page" value="<?php echo $blog['post_per_page']; ?>" required>
                </div>
                
                
               
                <div class="mb-3">
                    <label class="form-label">Blog Status</label>
                      <?php
                    $active ="";
                    $inactive ="";

                    if($blog['blog_status']=='Active'){
                        $active = 'selected';
                    }
                    if($blog['blog_status']=='InActive'){
                        $inactive = 'selected';

                    }
                    ?>
                    <select class="form-select" id="blog_status" name="blog_status" required>
                        <option value="Active" <?php echo $active; ?>>Active</option>
                        <option value="InActive" <?php echo $inactive; ?>>InActive</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">blog Background Image</label>
                    <input type="file" class="form-control" id="image" name="image" 
                    value="<?php echo $blog['blog_background_image']; ?>">
                </div>
                <input type="submit" name="update_blog" value="Update Blog" class="btn btn-primary">
                
            </form>
        </div>
    </div>
</div>
<script type="text/javascript" src="../../bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>

        <?php


    }


}





    






?>