<?php

include_once("../../Connection/Connection.php");
include_once("../Session_Admin.php");



?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Pages</title>
    <link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../../Css/sidebar.css">
   <link rel="stylesheet" type="text/css" href="../../Table/jquery.dataTables.min.css">
    <script type="text/javascript" src="../../Table/jquery-3.5.1.js"></script>
    <script type="text/javascript" src="../../Table/jquery.dataTables.min.js"></script>
    <script type="text/javascript">
        
        $(document).ready(function () {
        $('#example').DataTable();
    });
    </script>


</head>
<body>
<?php
    include_once("../NavBar/navbar.php");

?>

<div class="container-fluid">
        <div class="row">
            <?php
            include_once("../Sidebar/sidebar.php");
            ?>
          <div class="col-10 p-2">
            <h3 class="text-center">Blogs</h3>
              <div class="text-center bg-success">
            <?php 
                    if(isset($_GET['msg']))
                    {
                      ?>
                        <p  style="color: white; background-color: <?php echo $_GET['color']; ?>">
                          
                          <?php echo $_GET['msg']; ?>
                        </p>
                      <?php
                    }

                  ?> 

            </div>


            <table id="example" class="display" style="width:100%">
            <thead>
                <tr>
                    <th scope="col" class="text-center">Blog Id</th>
                    <th scope="col" class="text-center">Blog Title</th>
                    <th scope="col" class="text-center">Blog Background Image</th>
                    <th scope="col" class="text-center">Post Per Page</th>
                    <th scope="col" class="text-center">Status</th>
                    <th scope="col" class="text-center">Action</th>


                </tr>
            </thead>
            <tbody>
          
            <?php
      $current_user = $_SESSION['user']['user_id'];

              $Show_blog = "SELECT * FROM blog 
              INNER JOIN USER
              ON blog.`user_id` = user.`user_id`
              WHERE user.`user_id` ='".$current_user."'
              ORDER BY blog.`blog_id` DESC";
              $result = mysqli_query($connection, $Show_blog);

              if(mysqli_num_rows($result)>0){
                    while($blog = mysqli_fetch_assoc($result)){?>
                <tr>
                    <th scope="row" class="text-center"><?php echo $blog["blog_id"];?></th>
                    <td class="text-center"><?php echo $blog["blog_title"];?></td>
                    <td class="text-center">
                      <img src="Blog_Image/<?php echo $blog["blog_background_image"];?>"
                                     alt="Profile Image" style="width: 95px; height: 75px"
                                     class="rounded mx-auto d-block"></td>
                    <td class="text-center"><?php echo $blog["post_per_page"];?></td>
                  
                    <td class="text-center">
                    

                      <?php echo $blog["blog_status"];?>
                    </td>
                     <td class="text-center">
                        <a href="update_blog.php?id=<?php echo $blog["blog_id"];?>" class="btn btn-primary">Edit</a>
                        
                     </td>
                </tr>
              
            <?php
                
        }
    }

            ?>
            </tbody>
            </table>

          </div>
          <?php
        // include_once("Modal/status_Modal.php");
        ?>
	<script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>
              
</body>
</html>