<?php
    include_once("../Session_Admin.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Post</title>
    <link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../Css/Register.css">
    <link rel="stylesheet" type="text/css" href="../../Css/sidebar.css">


</head>
<body>
   <?php 
      require_once("../../Connection/Connection.php");
      // require_once 'Session_maintance.php';
      $current_user = $_SESSION['user']['user_id'];
      $getcategory = "SELECT * FROM `category` WHERE category_status = 'Active'";
      $result_category = mysqli_query($connection,$getcategory);

      $getblog = "SELECT * FROM `blog` WHERE user_id ='".$current_user."' AND blog_status = 'Active'";

      $result_blog = mysqli_query($connection,$getblog);
      

      include_once("../NavBar/navbar.php");

    ?>

<div class="container-fluid">
        <div class="row">
            <?php
            include_once("../Sidebar/sidebar.php");

   

            ?>
            <div class="col-6 pb-5 ps-5 pe-5 mx-auto" >
		 	<form action="../Process/update_process.php" method="POST" enctype="multipart/form-data">
				<h5 class="fw-normal text-center">Add Post</h5>
      <div class="col-12 text-center text-white">
      <?php 
                    if(isset($_GET['msg']))
                    {
                      ?>
                        <p class="alert alert-primary" role="alert">
                          
                          <?php echo $_GET['msg']; ?>
                        </p>
                      <?php
                    }

                  ?> 
      </div>
                  	
                  	
                  	
                  

                  	<div class="row">
                  		<div class="form-outline mb-1 col-12">
                    		<label class="form-label" for="form2Example17">Post Title</label>
                    		<input type="text" id="form2Example17" class="form-control form-control-lg" placeholder="Post title" name="title" />
                  		</div>
                  	</div>
                  

                  	<div class="form-outline mb-1">
                    	<label class="form-label" for="form2Example27">Post Summary</label>
                    	<textarea name="summary" id="Address" cols="30" rows="3" class="form-control form-control-lg"></textarea>
                  	</div>
                    <div class="form-outline mb-1">
                    	<label class="form-label" for="form2Example27">Post Description</label>
                    	<textarea name="description" id="Address" cols="30" rows="3" class="form-control form-control-lg"></textarea>
                  	</div>
                      <div class="row">
                  		<div class="form-outline mb-1 col-6">
                    		<label class="form-label" for="form2Example17">Select Blog:</label>
                    		<select class="form-select" name="blog" >
							    <?php 
                            while ($row = mysqli_fetch_assoc($result_blog)) 
                            {
                              ?>
                                <option value="<?php echo $row['blog_id']; ?>">
                                  <?php echo $row['blog_title']; ?> 
                                </option>
                              <?php   
                            }

                          ?>
							</select>
                  		</div>
                  		<div class="form-outline mb-1 col-6">
                    		<label class="form-label" for="form2Example17">Category:</label>
                    		<select class="form-select" name="category">
							           <?php 
                            while ($row = mysqli_fetch_assoc($result_category)) 
                            {
                              ?>
                                <option value="<?php echo $row['category_id']; ?>">
                                  <?php echo $row['category_title']; ?> 
                                </option>
                              <?php   
                            }

                          ?>
							</select>
                  		</div>
                  	</div>
                      <div class="row">
                  		<div class="form-outline mb-1 col-6">
                        <label class="form-label" for="form2Example17">Post Status:</label>
                        <select class="form-select" name="Post_Status" >
                <option value="Active">Active</option>
                <option value="InActive">InActive</option>
              </select>
                      </div>
                  		<div class="form-outline mb-1 col-6">
                    		<label class="form-label" for="form2Example17">Select In Image:</label>
                            <input type="file" name="image" class="form-control form-control-lg">
                    		
                  		</div>
                  	</div>
                    <div class="row">
                      <div class="form-outline mb-1 col-12">
                        <label class="form-label" for="form2Example17">Post Attachment Title</label>
                        <input type="text" id="form2Example17" class="form-control form-control-lg" placeholder="Post Attachment title" name="Attachment_title" />
                      </div>
                    </div>
                        <div class="row">
                     
                      <div class="form-outline mb-1 col-12">
                        <label class="form-label" for="form2Example17">Post Attachment:</label>
                            <input type="file" multiple name="multiple_Image[]"   class="form-control form-control-lg">
                        
                      </div>
                    </div>
                    
                    
                    
					<div class="row align-items-center pt-1 mt-2 mb-1">
						<div class="col-12 ">
						  	<input class="btn btn-lg btn-block" type="submit" value="Add Post" name="Add_post" style="background-color: #424874;">
						</div>
					</div>
			
	            </form>
		
			</div>

        </div>

    </div>
	
	
  
    

              
</body>
</html>