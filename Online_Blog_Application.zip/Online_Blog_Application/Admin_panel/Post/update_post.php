<?php
include_once("../../Connection/Connection.php");
session_start();
if (isset($_GET['id'])) {
  $post_id = $_GET['id'];


  $post_data = "SELECT post.`post_id`, blog.`blog_title`,post.`post_title`, 
                post.`post_summary`, post.`post_description`, post.`featured_image`, 
                category.`category_title`, post.`post_status`,post.`is_comment_allowed`, post.`created_at`,post.`updated_at` FROM post 
                INNER JOIN blog
                ON post.`blog_id` = blog.`blog_id`
                INNER JOIN post_category
                ON post.`post_id`= post_category.`post_id`
                INNER JOIN category
                ON category.`category_id` = post_category.`category_id`
                INNER JOIN post_atachment
                ON post.`post_id` = post_atachment.`post_id` 
                WHERE	 post.`post_id` = " . $post_id;
  $result = mysqli_query($connection, $post_data);

  if (mysqli_num_rows($result) > 0) {
    $post = mysqli_fetch_assoc($result);


?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Update Post</title>
      <link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
      <link rel="stylesheet" href="../../Css/Register.css">
      <link rel="stylesheet" type="text/css" href="../../Css/sidebar.css">


    </head>

    <body>

      <?php
      include_once("../NavBar/navbar.php");


      ?>
      <div class="container-fluid">
        <div class="row">
          <?php
          include_once("../Sidebar/sidebar.php");



          ?>
          <div class="col-6 pb-5 ps-5 pe-5 mx-auto">
            <h5 class="fw-normal text-center">Update Post</h5>
            <form action="../Process/update_process.php" method="POST" enctype="multipart/form-data">


              <?php
              $current_user = $_SESSION['user']['user_id'];





              ?>

              <div class="row">
                <div class="form-outline mb-1 col-6">
                  <label class="form-label" for="form2Example17">Select Blog:</label>
                  <select class="form-select" name="blog_post">
                    <?php

                    $get_blog = "SELECT * FROM blog 
                         INNER JOIN post 
                         ON blog.`blog_id` = post.`blog_id` 
                         WHERE post.post_id ='" . $post_id . "' AND user_id ='" . $current_user . "' AND blog_status = 'Active'";

                    $result_blog = mysqli_query($connection, $get_blog);
                    while ($row = mysqli_fetch_assoc($result_blog)) {
                    ?>
                      <option selected value="<?php echo $row['blog_id']; ?>">
                        <?php echo $row['blog_title']; ?>
                      </option>
                    <?php
                    }

                    ?>

                  </select>
                </div>
                <div class="form-outline mb-1 col-6">
                  <label class="form-label">Category</label>

                  <select class="form-select" id="is_active" name="post_category" required>
                    <?php
                    $get_category = "SELECT * FROM `category` WHERE category_status = 'Active'";
                    $result_category = mysqli_query($connection, $get_category);
                    while ($row = mysqli_fetch_assoc($result_category)) {
                    ?>
                      <option selected value="<?php echo $row['category_id']; ?>">
                        <?php echo $row['category_title']; ?>
                      </option>
                    <?php
                    }

                    ?>
                  </select>
                </div>
              </div>



              <div class="row">
                <input type="hidden" name="post_id" value="<?php echo $post['post_id']; ?>">
                <div class="form-outline mb-1 col-12">
                  <label class="form-label" for="form2Example17">Post Title</label>
                  <input type="text" id="form2Example17" class="form-control form-control-lg" placeholder="Post title" name="title" value="<?php echo $post['post_title']; ?>" />
                </div>
              </div>


              <div class="form-outline mb-1">
                <label class="form-label" for="form2Example27">Post Summary</label>
                <textarea name="summary" id="Address" cols="30" rows="3"><?php echo $post['post_summary']; ?></textarea>
              </div>
              <div class="form-outline mb-1">
                <label class="form-label" for="form2Example27">Post Description</label>
                <textarea name="description" id="Address" cols="30" rows="3"><?php echo $post['post_description']; ?></textarea>
              </div>

              <div class="row">
                <div class="form-outline mb-1 col-6">
                  <label class="form-label">Post Status</label>
                  <?php
                  $active = "";
                  $inactive = "";

                  if ($post['post_status'] == 'Active') {
                    $active = 'selected';
                  }
                  if ($post['post_status'] == 'InActive') {
                    $inactive = 'selected';
                  }
                  ?>
                  <select class="form-select" id="is_active" name="post_status" required>
                    <option value="Active" <?php echo $active; ?>>Active</option>
                    <option value="InActive" <?php echo $inactive; ?>>InActive</option>
                  </select>
                </div>
                <div class="form-outline mb-1 col-6">
                  <label class="form-label" for="form2Example17">Post Image:</label>
                  <input type="file" name="image" value="<?php echo $post['featured_image']; ?>" class="form-control form-control-lg">

                </div>
              </div>

              <div class="row">
                <div class="form-outline mb-1 col-12">
                  <label class="form-label">Comment</label>
                  <?php
                  $Enabled = "";
                  $Disabled = "";

                  if ($post['is_comment_allowed'] == 1) {
                    $Enabled = 'selected';
                  }
                  if ($post['is_comment_allowed'] == 0) {
                    $Disabled = 'selected';
                  }
                  ?>
                  <select class="form-select" id="is_active" name="post_comment" required>
                    <option value="1" <?php echo $Enabled; ?>>Enabled</option>
                    <option value="0" <?php echo $Disabled; ?>>Disabled</option>
                  </select>
                </div>

              </div>





              <div class="row align-items-center pt-1 mt-2 mb-1">
                <div class="col-12 ">
                  <input class="btn btn-lg btn-block" type="submit" value="Update Post" name="update_post">
                </div>
              </div>

            </form>

          </div>

        </div>

      </div>






    </body>

    </html>


<?php
  }
} ?>