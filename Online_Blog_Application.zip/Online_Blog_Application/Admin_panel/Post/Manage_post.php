<?php
    include_once("../Session_Admin.php");
  include_once("../../Connection/Connection.php");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Posts</title>
    <link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../../Css/sidebar.css">
    <link rel="stylesheet" type="text/css" href="../../Table/jquery.dataTables.min.css">
    <script type="text/javascript" src="../../Table/jquery-3.5.1.js"></script>
    <script type="text/javascript" src="../../Table/jquery.dataTables.min.js"></script>
    <script type="text/javascript">
        
        $(document).ready(function () {
        $('#example').DataTable();
    });
    </script>


</head>
<body>
<?php
  include_once("../NavBar/navbar.php");


?>
<div class="container-fluid">
        <div class="row">
           <?php
            include_once("../Sidebar/sidebar.php");
            ?>
          <div class="col-10 p-2">
            <h3 class="text-center">Post</h3>
             <div class="text-center bg-success">
            <?php 
                    if(isset($_GET['msg']))
                    {
                      ?>
                        <p   class="alert alert-primary" role="alert">
                          
                          <?php echo $_GET['msg']; ?>
                        </p>
                      <?php
                    }

                  ?> 

            </div>
             <div >

                <table id="example" class="display" style="width:100%">
                <thead>
                    
                        
                       <tr class="col-12">
                        <th scope="col" class="text-center">Post id</th>
                        <th scope="col" class="text-center">Blog </th>
                        <th scope="col" class="text-center">Title</th>
                        <th scope="col" class="text-center">Post Image</th>
                        <th scope="col" class="text-center">Summary</th>
                        <th scope="col" class="text-center">Category</th>
                        <th scope="col" class="text-center">Comments</th>
                        <th scope="col" class="text-center">Status</th>
                        <th scope="col" class="text-center">Action</th>

                    
                    </tr>
                        
                    </thead>


            <tbody class="table-group-divider">
              <?php
              $current_user = $_SESSION['user']['user_id'];

              $Show_post = " SELECT p.`post_id`, blog.`blog_title`,p.`post_title`, p.`post_summary`, p.`post_description`, p.`featured_image`, category.`category_title`, p.`post_status`,p.`is_comment_allowed`, p.`created_at`,p.`updated_at` FROM post p
              INNER JOIN blog
              ON p.`blog_id` = blog.`blog_id`
              INNER JOIN post_category
              ON p.`post_id`= post_category.`post_id`
              INNER JOIN category
              ON category.`category_id` = post_category.`category_id`
              INNER JOIN USER 
              ON blog.`user_id`= user.`user_id`
              WHERE user.`user_id`='".$current_user."'
              ORDER BY p.`post_id` DESC;
                            ";
              $result = mysqli_query($connection, $Show_post);

              if(mysqli_num_rows($result)>0){
                    while($post = mysqli_fetch_assoc($result)){?>
                <tr>
                    <th scope="row" class="text-center"><?php echo $post["post_id"];?></th>
                    <td class="col"><?php echo $post["blog_title"];?></td>
                    <td class="col"><?php echo $post["post_title"];?></td>
                    <td class="col"><img src="Post_Image/<?php echo $post["featured_image"];?>"style="width: 95px; height: 75px"
                                     class="rounded mx-auto d-block"></td>

                    <td class="col"><?php echo $post["post_summary"];?></td>
                    <!-- <td class="col"><?php echo $post["post_description"];?></td> -->
                    <td class="col"><?php echo $post["category_title"];?></td>
                   
                    <td class="text-center">
                      

                      <?php echo $post["is_comment_allowed"];?>


                    </td>
                    <td class="text-center">

                      <?php echo $post["post_status"];?>
                    </td>
                    <td class="text-center">
                          <a href="update_post.php?id=<?php echo $post['post_id']; ?>" class="btn btn-primary">Edit</a>
                      
                    </td>
               </tr>
               
            <?php
          }
        }?>
            </tbody>
                    
                </table>
            </div>
         
     
	<script type="text/javascript" src="../../bootstrap/js/bootstrap.bundle.min.js"></script>
              
</body>
</html>