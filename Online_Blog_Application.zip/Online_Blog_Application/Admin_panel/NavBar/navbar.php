<nav class="navbar navbar-expand-lg" style="background-color: #424874;">
    <div class="container-fluid">
        <a class="navbar-brand text-white" href="#">Online Blog Application</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarScroll">
            <ul class="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll" style="--bs-scroll-height: 100px;">
                <li class="nav-item">
                    <a class="nav-link active text-white" aria-current="page" href="#">Dashboard</a>
                </li>




            </ul>

        </div>
        <form class="d-flex h-10" role="profile">

            <h5 class=" me-2 btn btn-outline-light text-center">
                <?php
                echo $_SESSION['user']['first_name'] . " " . $_SESSION['user']['last_name'];

                ?>

            </h5>
            <a href="../../Logout.php">
                <h5 class=" btn btn-outline-light text-center">Logout</h5>
            </a>

        </form>
    </div>
</nav>