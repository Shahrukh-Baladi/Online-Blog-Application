<?php 
	
	session_start();
	if(isset($_SESSION['user']) && $_SESSION['user']['role_id'] != 1)
	{
		header("location: ../Login.php");
	}

	if(!isset($_SESSION['user']))
	{
		header("location: ../Login.php?msg=Please First Login&color=red");
	}


?>