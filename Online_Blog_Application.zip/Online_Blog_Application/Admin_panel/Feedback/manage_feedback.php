<?php
include_once("../Session_Admin.php");
include_once("../../Connection/Connection.php");

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Feedback</title>
  <link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="../../Css/sidebar.css">
  <link rel="stylesheet" type="text/css" href="../../Table/jquery.dataTables.min.css">
  <script type="text/javascript" src="../../Table/jquery-3.5.1.js"></script>
  <script type="text/javascript" src="../../Table/jquery.dataTables.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function() {
      $('#example').DataTable();
    });
  </script>



</head>

<body>
  <?php
  include_once("../NavBar/navbar.php");

  ?>
  <div class="container-fluid">
    <div class="row">
      <?php
      include_once("../Sidebar/sidebar.php");
      ?>
      <div class="col-10 p-2">
        <h3 class="text-center">Feedback</h3>
        <table id="example" class="display" style="width:100%">

          <thead>
            <div class="row">
              <tr class="col-12">
                <th scope="col-1" class="text-center">Feedback id</th>
                <th scope="col-1" class="text-center">User id</th>
                <th scope="col-1" class="text-center">User Name</th>
                <th scope="col-1" class="text-center">User Email</th>
                <th scope="col-1" class="text-center">Feedback</th>
                <th scope="col-1" class="text-center">Created</th>
                <th scope="col-1" class="text-center">Updated</th>

              </tr>
            </div>
          </thead>

          <tbody class="table-group-divider">
            <?php
            $Show_feedback = "SELECT * FROM user_feedback;";
            $result = mysqli_query($connection, $Show_feedback);

            if (mysqli_num_rows($result) > 0) {
              while ($feedback = mysqli_fetch_assoc($result)) { ?>

                <tr>
                  <th scope="row" class="text-center"><?php echo $feedback['feedback_id']; ?></th>
                  <td class="text-center">
                    <?php $user_id = $feedback['user_id'];

                    if ($user_id == "") {
                    ?>
                      <div class="alert alert-danger" role="alert">
                        <?php
                        echo "Not Registered";
                        ?>
                      </div>
                    <?php
                    } else {

                    ?>
                      <div class="alert alert-success" role="alert">
                        <?php
                        echo "Registered";

                        ?>
                      </div>
                    <?php
                    }


                    ?>
                  </td>
                  <td class="text-center"><?php echo $feedback['user_name']; ?></td>
                  <td class="text-center"><?php echo $feedback['user_email']; ?></td>
                  <td class="text-center"><?php echo $feedback['feedback']; ?></td>
                  <td class="text-center"><?php echo $feedback['created_at']; ?></td>
                  <td class="text-center"><?php echo $feedback['updated_at']; ?></td>
                </tr>







            <?php
              }
            } ?>
          </tbody>
        </table>

      </div>


</body>

</html>