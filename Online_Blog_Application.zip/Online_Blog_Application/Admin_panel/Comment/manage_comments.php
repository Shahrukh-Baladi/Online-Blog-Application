<?php
    include_once("../Session_Admin.php");
require_once("../../Connection/Connection.php");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Comment</title>
    <link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../../Css/sidebar.css">
    <link rel="stylesheet" type="text/css" href="../../Table/jquery.dataTables.min.css">
    <script type="text/javascript" src="../../Table/jquery-3.5.1.js"></script>
    <script type="text/javascript" src="../../Table/jquery.dataTables.min.js"></script>
    <script type="text/javascript">
        
        $(document).ready(function () {
        $('#example').DataTable();
    });
    </script>


</head>
<body>
<?php
    include_once("../NavBar/navbar.php");

?>

<div class="container-fluid">
        <div class="row">
           
            <?php
            include_once("../Sidebar/sidebar.php");
            ?>


     


          
          <div class="col-10 p-2">
            <h3 class="text-center">Comment</h3>
          <table id="example" class="display" style="width:100%">
            
              <thead>
                <div class="row">
                    <tr class="col-12">
                        <th class="col text-center">Post Comment id</th>
                        <th class="col text-center">Post Title</th>
                        <th class="col text-center">Username</th>
                        <th class="col text-center">Email</th>
                        <th class="col text-center">Comment</th>
                        <th class="col text-center">Created At</th>
                        <th class="col text-center">Status</th>
                        <th class="col text-center">Action</th>

                    </tr>
                </div>
            </thead>
            <tbody class="table-group-divider">
            <?php
            $post_comment_query = "
                      
                SELECT post_comment.*, post.`post_id`, post.`post_title`, user.`first_name`, user.`last_name`, user.`email`, user.`user_image` 
                FROM post_comment 
                INNER JOIN USER
                ON post_comment.`user_id` = user.`user_id`
                INNER JOIN post
                ON post_comment.`post_id` = post.`post_id`;
    
                
                ";
                $result = mysqli_query($connection, $post_comment_query);
                while($post = mysqli_fetch_assoc($result)){?>
                <tr>
                    <th scope="row" class="text-center"><?php echo $post['post_comment_id'];?></th>
                    <td class="text-center"><?php echo $post["post_title"];?></td>
                    <td class="text-center"><?php echo $post["first_name"]." ".$post['last_name'];?></td>
                    <td class="text-center"><?php echo $post["email"];?></td>
                    <td class="text-center"><?php echo $post["comment"];?></td>
                    <td class="text-center"><?php echo $post["created_at"];?></td>
                    <td class="text-center"><?php echo $post["is_active"];?></td>
                    <td class="text-center">
                        
                        <a href="update_status.php?id=<?php echo $post['post_comment_id']; ?>"
                                   class="btn btn-primary">Update</a>
                               
                    </td>

               </tr>
              
               
               
               
            <?php
              }
            ?>
            </tbody>
            </table>

          </div>
          
           
	<script type="text/javascript" src="../../bootstrap/js/bootstrap.bundle.min.js"></script>
              
</body>
</html>