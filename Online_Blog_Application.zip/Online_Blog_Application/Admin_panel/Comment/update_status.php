<?php


require_once("../../Connection/Connection.php");
include_once("../Session_Admin.php");



if (isset($_GET['id'])) {
    $post_comment_id = $_GET['id'];




    $post_comment_query =   
                "SELECT pc.*, user.`first_name`, user.`last_name`, user.`email`, post.`post_title`  FROM post_comment pc 
                INNER JOIN USER
                ON pc.`user_id` = user.`user_id`
                INNER JOIN post
                ON pc.`post_id` = post.`post_id`
                WHERE pc.`post_comment_id`  =".$post_comment_id;



            


    $result = mysqli_query($connection, $post_comment_query);

    if (mysqli_num_rows($result) > 0) {
        $comment = mysqli_fetch_assoc($result);
    
    ?>
   
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Post Comment Status</title>
    <link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../Css/Home.css">
    <link rel="stylesheet" type="text/css" href="../../Css/sidebar.css">

</head>
<body>
<?php
    include_once("../NavBar/navbar.php");

?>
<div class="container-fluid">
    <div class="row">
        <?php
        include_once("../Sidebar/sidebar.php");
        ?>
        <div class="col-10 p-2">
            <h3 class="text-center">Comment</h3>
            <form method="post" action="../Process/update_process.php" enctype="multipart/form-data">
                <input type="hidden" name="comment_id" value="<?php echo $comment['post_comment_id']; ?>">
                <div class="mb-3">
                    <label for="first_name" class="form-label">Post Comment Id</label>
                    <input type="text" disabled  class="form-control" id="first_name" name="first_name" value="<?php echo $comment['post_comment_id'];?>" required>
                </div>
                <div class="mb-3">
                    <label for="last_name"  class="form-label">Post Title</label>
                    <input type="text" disabled class="form-control" id="last_name" name="last_name" value="<?php echo $comment['post_title']; ?>" required>
                </div>
                <div class="mb-3">
                Username</label>
                    <input type="email" class="form-control" disabled id="email"  name="email" value="<?php echo $comment['first_name']; ?>" >
                </div>
                <div class="mb-3">
                Email</label>
                    <input type="email" disabled class="form-control" id="email"  name="email" value="<?php echo $comment['email']; ?>" >
                </div>
                <div class="mb-3">
                    <label for="address" class="form-label">comment</label>
                    <textarea class="form-control" disabled id="address" name="address" rows="3" required><?php echo $comment['comment']; ?></textarea>
                </div>
                <div>

                    <label class="form-label">Is_Active</label>
                       <?php
                            $active ="";
                            $inactive ="";

                            if($comment['is_active']=='Active'){
                                $active = 'selected';
                            }
                            if($comment['is_active']=='InActive'){
                                $inactive = 'selected';

                            }
                            ?>
                    <select class="form-select" id="is_active" name="is_active" required>  
                                <option value="Active" <?php echo $active; ?>>Active</option>
                                <option value="InActive" <?php echo $inactive; ?>>InActive</option>
                    </select>
                </div>
                
                <div class="m-2">
                    <input type="submit" name="update_comment" value="update" class="btn btn-primary">
                </div>
            </form>
        </div>
    </div>
</div>
<script type="text/javascript" src="../../bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
    }




    
    


}



?>