<?php
include_once("../../Connection/Connection.php");
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>User Profile</title>
	<link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../../Css/sidebar.css">
	<link rel="stylesheet" href="../../Css/Register.css">

</head>

<body>
	<?php
	include_once("../NavBar/navbar.php");

	?>

	<div class="container-fluid">
		<div class="row">
			<?php
			$current_user = $_SESSION['user']['user_id'];
			include_once("../Sidebar/sidebar.php");

			$user   = "SELECT * FROM USER WHERE user_id = " . $current_user;
			$result = mysqli_query($connection, $user);


			while ($row = mysqli_fetch_assoc($result)) {




			?>

				<div class="col-4 ">
					<div class="card mb-4 mt-1 ms-1">
						<div class="card-body text-center">
							<img src="../../User_Image/<?php echo $row['user_image']; ?>" alt="avatar" class="rounded-circle img-fluid" style="width: 150px;">
							<h5 class="my-3">
								<?php echo $row['first_name'] . " " . $row['last_name']; ?>
							</h5>

							<p class="text-muted mb-1">
								<?php echo $row['email']; ?>

							</p>
							<div class="d-flex justify-content-center mb-2">
								<a href="update_admin_profile.php?id=<?php echo $row['user_id']; ?>" class="btn btn-primary">Update</a>
							</div>

						</div>
					</div>
				</div>

				<div class="col-lg-6 mt-1">
					<div class="card mb-4">
						<div class="card-body">
							<div class="row">
								<div class="col-sm-3">
									<p class="mb-0">First Name</p>
								</div>
								<div class="col-sm-9">
									<p class="text-muted mb-0">

										<?php echo $row['first_name']; ?>
									</p>
								</div>
							</div>
							<hr>

							<div class="row">
								<div class="col-sm-3">
									<p class="mb-0">Last Name</p>
								</div>
								<div class="col-sm-9">
									<p class="text-muted mb-0">
										<?php echo $row['last_name']; ?>
									</p>
								</div>
							</div>
							<hr>
							<div class="row">
								<div class="col-sm-3">
									<p class="mb-0">Email</p>
								</div>
								<div class="col-sm-9">
									<p class="text-muted mb-0">
										<?php echo $row['email']; ?>

									</p>
								</div>
							</div>
							<hr>
							<div class="row">
								<div class="col-sm-3">
									<p class="mb-0">Gender</p>
								</div>
								<div class="col-sm-9">
									<p class="text-muted mb-0">
										<?php echo $row['gender']; ?>

									</p>
								</div>
							</div>
							<hr>


							<div class="row">
								<div class="col-sm-3">
									<p class="mb-0">Date Of Birth</p>
								</div>
								<div class="col-sm-9">
									<p class="text-muted mb-0">
										<?php echo $row['date_of_birth']; ?>

									</p>
								</div>
							</div>

							<hr>
							<div class="row">
								<div class="col-sm-3">
									<p class="mb-0">Password</p>
								</div>
								<div class="col-sm-9">
									<p class="text-muted mb-0">
										<?php echo $row['password']; ?>

									</p>
								</div>
							</div>


						</div>

					<?php
				}


					?>


					<script type="text/javascript" src="../bootstrap/js/bootstrap.bundle.min.js"></script>






</body>

</html>