

<?php
include_once("../../Connection/Connection.php");
session_start();


if (isset($_GET['id'])) {
    $user_id = $_GET['id'];


    $User_query = "SELECT * FROM user WHERE user_id = ".$user_id;
    $result = mysqli_query($connection, $User_query);

    if (mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
    

        ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update User</title>
    <link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../Css/Home.css">
    <link rel="stylesheet" type="text/css" href="../Css/sidebar.css">

</head>
<body>
<?php
    include_once("../NavBar/navbar.php");

?>
<div class="container-fluid">
    <div class="row">
        
        <div class="col-10 p-2 mx-auto">
            <h3 class="text-center">Update Profile</h3>
            <form method="post" action="../Process/update_process.php" enctype="multipart/form-data">
                <input type="hidden" name="user_id" value="<?php echo $user['user_id']; ?>">
                <input type="hidden" name="role_id" value="<?php echo $user['role_id']; ?>">


                <div class="mb-3">
                    <label for="first_name" class="form-label">First Name</label>
                    <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo $user['first_name']; ?>" required>
                </div>
                <div class="mb-3">
                    <label for="last_name" class="form-label">Last Name</label>
                    <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo $user['last_name']; ?>" required>
                </div>
                <div class="mb-3">
				Email</label>
                    <input type="email" class="form-control" id="email"  name="email" value="<?php echo $user['email']; ?>" >
                </div>
                <div class="mb-3">
                    <label for="address" class="form-label">Address</label>
                    <textarea class="form-control" id="address" name="address" rows="3" required><?php echo $user['address']; ?></textarea>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" name="password" value='<?php echo $user['password']; ?>' required  >
                </div>
                <div class="mb-3">
                    <label class="form-label">Gender</label>
                    <?php
                    $male ="";
                    $female ="";

                    if($user['gender']=='Male'){
                        $male = 'selected';
                    }
                    if($user['gender']=='Female'){
                        $female = 'selected';

                    }
                    ?>

                    <select class="form-select" id="gender" name="gender" required>
                        <option value="Male" <?php echo $male; ?>>Male</option>
                        <option value="Female" <?php echo $female; ?>>Female</option>
                       
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Is_Active<?php echo $user['is_active']; ?></label>
                      <?php
                    $active ="";
                    $inactive ="";

                    if($user['is_active']=='Active'){
                        $active = 'selected';
                    }
                    if($user['is_active']=='InActive'){
                        $inactive = 'selected';

                    }
                    ?>
                    <select class="form-select" id="is_active" name="is_active" required>
                        <option value="Active" <?php echo $active; ?>>Active</option>
                        <option value="InActive" <?php echo $inactive; ?>>InActive</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label  class="form-label">Date of Birth</label>
                    <input type="date" class="form-control" id="date_of_birth" name="date_of_birth" value="<?php echo $user['date_of_birth']; ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Profile</label>
                    <input type="file" class="form-control" id="image" name="image" value="<?php echo $user['user_image']; ?>">
                </div>
                <input type="submit" class="btn btn-primary" name="update_profile" value="Update">
                
            </form>
        </div>
    </div>
</div>
<script type="text/javascript" src="../../bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
	}

}
?>