<?php
include_once("../Session_Admin.php");

?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Add User</title>
	<link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="../../Css/Register.css">
	<link rel="stylesheet" type="text/css" href="../../Css/sidebar.css">

	<!-- <link rel="stylesheet" href="../../Javascript/Form_Validation.js"> -->


</head>

<body>

	<?php
	require_once("../../Connection/Connection.php");


	$getRolesQuery = "SELECT * FROM `role`";
	$result = mysqli_query($connection, $getRolesQuery);


	include_once("../NavBar/navbar.php");

	?>
	<div class="container-fluid">
		<div class="row">
			<?php
			include_once("../Sidebar/sidebar.php");
			?>
			<div class="col-6 pb-5 ps-5 pe-5 mx-auto">
				<form action="../Process/update_process.php" method="POST" enctype="multipart/form-data">
					<h5 class="fw-normal text-center">Add User</h5>
					<div class="col-12 text-center fw-bold text-white">
						<?php
						if (isset($_GET['msg'])) {
						?>
							<alert  class="alert alert-primary" role="alert">

								<?php echo $_GET['msg']; ?>
							</alert>
						<?php
						}

						?>

					</div>




					<div class="row">
						<div class="form-outline mb-1 col-6">
							<label class="form-label" for="form2Example17">First Name</label>
							<input type="text" id="first_name" class="form-control form-control-lg" placeholder="First Name" name="first_name" />
							<span class="text-danger ms-2"></span>
							<br>
						</div>
						<div class="form-outline mb-1 col-6">
							<label class="form-label" for="form2Example17">Last Name</label>
							<input type="text" id="form2Example17" class="form-control form-control-lg" placeholder="Last Name" name="last_name" />
						</div>
					</div>


					<div class="form-outline mb-1">
						<label class="form-label" for="form2Example27">Email</label>
						<input type="email" id="form2Example27" class="form-control form-control-lg" placeholder="Email" name="email" />
					</div>
					<div class="row">
						<label>Gender:</label>
						<div class="col-6">
							<div class="form-check">
								<input class="form-check-input" name="gender" type="radio" id="flexCheckChecked" value="Male">
								<label class="form-check-label">
									Male
								</label>
							</div>
						</div>
						<div class="col-6">
							<div class="form-check">
								<input class="form-check-input" name="gender" type="radio" id="flexCheckChecked" value="Female">
								<label class="form-check-label">
									Female
								</label>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="form-outline mb-1 col-6">
							<label class="form-label" for="form2Example17">Date Of Birth:</label>
							<input type="Date" id="form2Example17" class="form-control form-control-lg" placeholder="Date Of Birth" name="date_of_birth" />
						</div>
						<div class="form-outline mb-1 col-6">
							<label class="form-label" for="form2Example17">Role:</label>
							<select class="form-select" name="role">

								<?php
								while ($row = mysqli_fetch_assoc($result)) {
								?>
									<option value="<?php echo $row['role_id']; ?>">
										<?php echo $row['role_type']; ?>
									</option>
								<?php
								}

								?>
							</select>
						</div>

					</div>
					<div class="col-12">
						<label class="form-label" for="form2Example27">Address</label>
						<textarea name="address" id="Address" cols="30" rows="3" class="form-control form-control-lg"></textarea>
					</div>
					<div class="form-outline mb-1 col-12">
						<label class="form-label" for="form2Example17">Select In Image:</label>
						<input type="file" name="image" class="form-control form-control-lg">

					</div>
					<div class="form-outline mb-1">
						<label class="form-label" for="form2Example27">Password</label>
						<input type="Password" id="form2Example27" class="form-control form-control-lg" placeholder="Password" name="password" />
					</div>
					<div class="row align-items-center pt-1 mt-2 mb-1">
						<div class="col-12 ">
							<input class="btn btn-lg btn-block" type="submit" value="Add User" name="Add_user" style="background-color: #424874;">
						</div>
					</div>

				</form>

			</div>

		</div>

	</div>






</body>

</html>