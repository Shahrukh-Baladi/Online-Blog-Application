<?php
include_once("../../Connection/Connection.php");
include_once("../Session_Admin.php");

$All_User = "SELECT * FROM `user` WHERE is_approved = 'Approved' AND role_id = 2;";
$result = mysqli_query($connection, $All_User);


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage User</title>
    <link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../Css/Home.css">
    <link rel="stylesheet" type="text/css" href="../../Css/sidebar.css">
    <link rel="stylesheet" type="text/css" href="../../Table/jquery.dataTables.min.css">
    <script type="text/javascript" src="../../Table/jquery-3.5.1.js"></script>
    <script type="text/javascript" src="../../Table/jquery.dataTables.min.js"></script>
    <script type="text/javascript">
        
        $(document).ready(function () {
        $('#example').DataTable();
    });
    </script>
</head>
<body>
<?php
    include_once("../NavBar/navbar.php");

?>

<div class="container-fluid">
    <div class="row">
        <?php include_once("../Sidebar/sidebar.php"); ?>

        <div class="col-10 p-2">
            <h3 class="text-center">Users</h3>
            <div class="text-center">
                <?php
                if (isset($_GET['msg'])) {
                    ?>
                    <p  class="alert alert-primary" role="alert">
                        <?php echo $_GET['msg']; ?>
                    </p>
                    <?php
                }
                require_once("button/buttons.php");
                ?>
            </div>
        

            <div id="approved_users">
                <h4 class="text-center">Approved Users</h4>

                <table id="example" class="display" style="width:100%">
                    <thead>
                    <tr>   
                        <tr>
                        <th scope="col" class="text-center">User Id</th>
                        <th scope="col" class="text-center">Profile</th>
                        <th scope="col" class="text-center">Username</th>
                        <th scope="col" class="text-center">Email</th>
                        <th scope="col" class="text-center">Password</th>
                        <th scope="col" class="text-center">Gender</th>
                        <th scope="col" class="text-center">Is_Active</th>
                        <th scope="col" class="text-center">Is_Approved</th>
                        <th scope="col" class="text-center">Action</th>
                    </tr>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    while ($row = mysqli_fetch_assoc($result)) {
                        ?>
                     
                      <tr>
                            <td class="text-center"><?php echo $row['user_id']; ?></td>
                            <td class="text-center">
                                <a href="UserProfile.php?id=<?php echo $row['user_id']; ?>">
                                <img src="../../User_Image/<?php echo $row["user_image"]; ?>"
                                     alt="Profile Image" style="width: 45px; height: 45px"
                                     class="rounded-circle">
                                </a>
                            </td>
                            <td class="text-center"><?php echo $row['first_name'] . ' ' . $row['last_name']; ?></td>
                            
                            <td class="text-center"><?php echo $row["email"]; ?></td>
                            <td class="text-center"><?php echo $row["password"]; ?></td>
                            <td class="text-center"><?php echo $row["gender"]; ?></td>
                            <td class="text-center">
                                <?php echo $row['is_active']; ?>
                            </td>
                            <td class="text-center">
                                <button class="btn bg-success text-white" >
                                    <?php echo $row['is_approved']; ?>
                                </button>
                            </td>
                            
                        <td class="text-center">
                                <a href="update_user.php?id=<?php echo $row['user_id']; ?>"
                                   class="btn btn-primary">Update</a>
                               
                        </td>
                               
                       
                        </tr>
                      
                        <?php
                    }
                    ?>
                    </tbody>
                </table>
            </div>

                </body>
</html>