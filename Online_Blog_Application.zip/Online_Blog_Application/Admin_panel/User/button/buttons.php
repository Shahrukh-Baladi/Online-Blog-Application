            <div class="row mb-3 text-center">
                <div class="col">
                    <a href="approved_user.php"class="btn btn-success" id="approved">Approved Users
                        
                    </a>
                </div>
                <div class="col">
                   
                    <a href="manage_user.php"
                                   class="btn btn-primary" id="pending">Pending Users</a>
                </div>
                <div class="col">
                    <a href="rejected_user.php"class="btn btn-danger" id="rejected">Rejected Users
                      
                    </a>
                </div>
            </div>