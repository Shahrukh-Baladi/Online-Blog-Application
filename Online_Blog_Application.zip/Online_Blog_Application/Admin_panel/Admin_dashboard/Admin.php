<?php
// include_once("../Session_Admin.php");
require_once("../../Connection/Connection.php");
session_start();

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard</title>
  <link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="../../Css/Register.css">
  <link rel="stylesheet" type="text/css" href="../../Css/sidebar.css">


</head>

<body>
  <?php



  include_once("../NavBar/navbar.php");

  ?>

  <div class="container-fluid">

    <div class="row">
      <?php
      include_once("../Sidebar/sidebar.php");



      ?>
      <div class="col-10">
        <div class="row m-2">
          <h2 class="alert alert-primary text-dark text-center" role="alert">
            Welcome To Admin Dashboard
          </h2>
        </div>


        <div class="row m-2">
          <div class="col-3 mx-auto ">
            <div class="card shadow text-dark" style="width: 15rem;">
              <div class="card-body">
                <img src="../../Icons/boy.png" alt="" class="w-50 mx-auto d-block">
                <h5 class="card-title text-center">All Users</h5>
                <?php $All_user = "SELECT COUNT(*) AS All_USER FROM USER";
                $user = mysqli_query($connection, $All_user);

                if (mysqli_num_rows($user) > 0) {
                  $blog = mysqli_fetch_assoc($user);
                ?>


                  <h1 class="card-subtitle mb-2 text-body-secondary text-center">
                    <?php
                    echo $blog['All_USER'];
                    ?>
                  </h1>
                <?php }


                ?>

              </div>
            </div>
          </div>
          <div class="col-3 mx-auto ">
            <div class="card shadow text-dark bg-light" style="width: 15rem;">
              <div class="card-body">
                <img src="../../Icons/pending.png" alt="" class="w-50 mx-auto d-block">
                <h5 class="card-title text-center">Pending Users</h5>
                <?php $All_user = "SELECT COUNT(*) AS All_USER FROM USER WHERE is_approved = 'Pending'
";
                $user = mysqli_query($connection, $All_user);

                if (mysqli_num_rows($user) > 0) {
                  $pending = mysqli_fetch_assoc($user);
                ?>


                  <h1 class="card-subtitle mb-2 text-body-secondary text-center">
                    <?php
                    echo $pending['All_USER'];
                    ?>
                  </h1>
                <?php }


                ?>

              </div>
            </div>
          </div>
          <div class="col-3 mx-auto ">
            <div class="card shadow text-dark bg-light" style="width: 15rem;">
              <div class="card-body">
                <img src="../../Icons/check.png" alt="" class="w-50 mx-auto d-block">
                <h5 class="card-title text-center">Approved Users</h5>
                <?php $All_user = "SELECT COUNT(*) AS All_USER FROM USER where is_approved = 'Approved'";
                $user = mysqli_query($connection, $All_user);

                if (mysqli_num_rows($user) > 0) {
                  $approved = mysqli_fetch_assoc($user);
                ?>

                  <h1 class="card-subtitle mb-2 text-body-secondary text-center">
                    <?php
                    echo $approved['All_USER'];
                    ?>
                  </h1>
                <?php }


                ?>

              </div>
            </div>
          </div>
          <div class="col-3 mx-auto ">
            <div class="card shadow text-dark bg-light" style="width: 15rem;">
              <div class="card-body">
                <img src="../../Icons/remove.png" alt="" class="w-50 mx-auto d-block">
                <h5 class="card-title text-center">Rejected Users</h5>
                <?php $All_user = "SELECT COUNT(*) AS All_USER FROM USER WHERE is_approved = 'Rejected'";
                $user = mysqli_query($connection, $All_user);

                if (mysqli_num_rows($user) > 0) {
                  $rejected = mysqli_fetch_assoc($user);
                ?>


                  <h1 class="card-subtitle mb-2 text-body-secondary text-center">
                    <?php
                    echo $rejected['All_USER'];
                    ?>
                  </h1>
                <?php }


                ?>

              </div>
            </div>
          </div>


        </div>


        <div class="row m-2">

          <div class="col-3 mx-auto ">
            <div class="card shadow text-dark bg-light" style="width: 15rem;">
              <div class="card-body">
                <img src="../../Icons/blog.png" alt="" class="w-50 mx-auto d-block">
                <h5 class="card-title text-center">Blogs</h5>
                <?php
                $current_user = $_SESSION['user']['user_id'];

                $All_Blog = "SELECT COUNT(*) AS All_Blog FROM blog 
                                        INNER JOIN USER
                                        ON blog.`user_id` = user.`user_id`
                                        WHERE user.`user_id` =" . $current_user;
                $Blog = mysqli_query($connection, $All_Blog);

                if (mysqli_num_rows($Blog) > 0) {
                  $blog_result = mysqli_fetch_assoc($Blog);
                ?>


                  <h1 class="card-subtitle mb-2 text-body-secondary text-center">
                    <?php
                    echo $blog_result['All_Blog'];
                    ?>
                  </h1>
                <?php }


                ?>

              </div>
            </div>
          </div>
          <div class="col-3 mx-auto ">
            <div class="card shadow text-dark bg-light" style="width: 15rem;">
              <div class="card-body">
                <img src="../../Icons/options.png" alt="" class="w-50 mx-auto d-block">
                <h5 class="card-title text-center">All Category</h5>
                <?php $All_Category = "SELECT COUNT(*) AS All_Category FROM category";
                $Category = mysqli_query($connection, $All_Category);

                if (mysqli_num_rows($Category) > 0) {
                  $category_result = mysqli_fetch_assoc($Category);
                ?>

                  <h1 class="card-subtitle mb-2 text-body-secondary text-center">
                    <?php
                    echo $category_result['All_Category'];
                    ?>
                  </h1>
                <?php }


                ?>

              </div>
            </div>
          </div>
          <div class="col-3 mx-auto ">
            <div class="card shadow text-dark bg-light" style="width: 15rem;">
              <div class="card-body">
                <img src="../../Icons/feedback.png" alt="" class="w-50 mx-auto d-block">
                <h5 class="card-title text-center">Feedback</h5>
                <?php
                $All_Feedback = "SELECT COUNT(*) AS All_Feedback FROM user_feedback";
                $feedback = mysqli_query($connection, $All_Feedback);

                if (mysqli_num_rows($feedback) > 0) {
                  $feedback_result = mysqli_fetch_assoc($feedback);
                ?>

                  <h1 class="card-subtitle mb-2 text-body-secondary text-center">
                    <?php
                    echo $feedback_result['All_Feedback'];
                    ?>
                  </h1>
                <?php }


                ?>

              </div>
            </div>
          </div>
          <div class="col-3 mx-auto ">
            <div class="card shadow text-dark bg-light" style="width: 15rem;">
              <div class="card-body">
                <img src="../../Icons/comments.png" alt="" class="w-50 mx-auto d-block">
                <h5 class="card-title text-center">Comments</h5>
                <?php $All_Comment = "SELECT COUNT(*) AS All_Comment FROM post_comment";
                $Comment = mysqli_query($connection, $All_Comment);

                if (mysqli_num_rows($Comment) > 0) {
                  $Comment_result = mysqli_fetch_assoc($Comment);
                ?>


                  <h1 class="card-subtitle mb-2 text-body-secondary text-center">
                    <?php
                    echo $Comment_result['All_Comment'];
                    ?>
                  </h1>
                <?php }


                ?>

              </div>
            </div>
          </div>

        </div>



      </div>







</body>

</html>