

       <div class="col-2 sidebar" style="height: auto;">
        <ul class="nav flex-column">
          <li class="nav-item">
            <a class="nav-link active" href="../Profile/Profile.php">
              <img src="../../Icons/boy.png" alt="profile" width="25" height="25"> Profile
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="../Admin_dashboard/Admin.php">
              <img src="../../Icons/business-report.png" alt="Home" width="25" height="25">Dashboard
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="../User/Add_user.php">
              <img src="../../Icons/add-user.png" alt="Add User" width="25" height="25"> Add User
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="../Post/Add_post.php">
              <img src="../../Icons/new-document.png" alt="Add Post" width="25" height="25"> Add Post
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="../Category/Add_category.php">
              <img src="../../Icons/menu.png" alt="Add Category" width="25" height="25"> Add Category
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="../Blog/Add_page.php">
              <img src="../../Icons/multiple.png" alt="Add Page" width="25" height="25"> Add Blog
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="../User/manage_user.php"> 
              <img src="../../Icons/profile (2).png" alt="Manage User" width="25" height="25"> Manage User
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="../Blog/manage_pages.php">
              <img src="../../Icons/blog.png" alt="Manage Pages" width="25" height="25"> Manage Blog 
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="../Category/manage_category.php">
              <img src="../../Icons/options.png" alt="Manage Category" width="25" height="25"> Manage Category
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="../Post/Manage_post.php">
            <img src="../../Icons/post.png" alt="Manage Post" width="25" height="25"> Manage Post
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="../Comment/manage_comments.php">
              <img src="../../Icons/comments.png" alt="Manage Comments" width="25" height="25"> Manage Comments
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="../Feedback/manage_feedback.php">
              <img src="../../Icons/feedback.png" alt="Feedback" width="25" height="25"> Manage Feedback
            </a>
          </li>
          <form action="Login.php" method="Post">
            <li class="nav-item">
              <a class="nav-link active" href="../../Logout.php">
                <img src="../../Icons/switch.png" alt="Logout" width="25" height="25"> Logout
              </a>
            </li>
          </form>
        </ul>
      </div>
      <!-- Main Content -->
  
