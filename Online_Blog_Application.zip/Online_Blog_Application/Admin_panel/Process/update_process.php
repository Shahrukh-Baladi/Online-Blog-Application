<?php


require_once("../../Connection/Connection.php");
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    require '../../PHPMailer/src/PHPMailer.php';
    require '../../PHPMailer/src/SMTP.php';
    require '../../PHPMailer/src/Exception.php';

session_start();



//Update Category 


if (isset($_POST['update_category'])) {
        $category_id          = $_POST['category_id'];
        $category_title       = $_POST['title'];
        $category_description = $_POST['description'];
        $category_status      = $_POST['status'];

        


        

   
        $update_category = "UPDATE category SET category_title = '".$category_title."', category_description = '".$category_description."', category_status = '".$category_status."' WHERE category_id=".$category_id;
        $Category_update = mysqli_query($connection, $update_category);

      
      
  
        if ($Category_update) {
            $msg = "Category updated successfully.";
            header("Location: ../Category/manage_category.php?msg=$msg&color=green");
        } else {
            $msg = "Failed to update category.";
            header("Location: ../Category/manage_category.php?msg=$msg&color=red");
        }
    } 
//Update Category Ends

    //Update Blog

    if (isset($_POST['update_blog'])) {
    
    $blogId         = $_POST['blog_id'];
    $blog_title    = $_POST['title'];
    $number_of_post = $_POST['post_per_page'];
    $status         = $_POST['blog_status'];


        $folder = "../Blog/Blog_Image";

        $filename   = rand().$_FILES['image']['name'];
        $temp_name  = $_FILES['image']['tmp_name'];
    

   
        move_uploaded_file($temp_name, $folder."/".$filename);

   
   
    $updateQuery = "UPDATE blog SET blog_title = '".$blog_title."', post_per_page = '".$number_of_post."',blog_status = '".$status."', blog_background_image='".$filename."'  WHERE blog_id = $blogId";
    $result = mysqli_query($connection, $updateQuery);
    
    
    if ($result) {
        $msg = "Blog Status updated";
        header("location: ../Blog/manage_pages.php?msg=$msg&color=green");
    } else {
        $msg = "Blog Status Remain Same";
        header("location: ../Blog/manage_pages.php?msg=$msg&color=red");
    }



}
    //update blog Ends


    //update Post


    if (isset($_POST['update_post'])) {
    
    $post_id             = $_POST['post_id'];
    $post_title          = $_POST['title'];
    $post_summary        = $_POST['summary'];
    $post_description    = $_POST['description'];
    $status              = $_POST['post_status'];
    $post_category       = $_POST['post_category'];
    $blog_post           = $_POST['blog_post'];
    $post_comment        = $_POST['post_comment'];


        $folder = "../Post/Post_Image";

        $filename   = rand().$_FILES['image']['name'];
        $temp_name  = $_FILES['image']['tmp_name'];
    

   
        move_uploaded_file($temp_name, $folder."/".$filename);

        
        $update_post = "UPDATE post SET post_title = '".$post_title."', blog_id = '".$blog_post."',   post_summary = '".$post_summary."', post_status = '".$status."', is_comment_allowed = '".$post_comment."', post_description = '".$post_description."', featured_image = '".$filename."' WHERE post_id = '".$post_id."'";

        $result = mysqli_query($connection, $update_post);
       
        
     
    if ($result) {
        $update_post_category = "UPDATE post_category SET category_id = '".$post_category."' WHERE post_id = '".$post_id."'";
        $result = mysqli_query($connection, $update_post_category);

        $msg = "Post updated";
        header("location: ../Post/Manage_post.php?msg=$msg&color=green");
    } else {
        $msg = "Post Remain Same";
        header("location: ../Post/Manage_post.php?msg=$msg&color=red");
    }



}

//Update Post Ends

//Active/Inactive Comment

if (isset($_POST['update_comment'])) {
    $comment_status = $_POST['is_active'];
    $comment_id = $_POST['comment_id'];

    $update_comment = "UPDATE post_comment SET is_active = '".$comment_status."' WHERE post_comment_id  = '".$comment_id."'";
    $comment_update = mysqli_query($connection, $update_comment);



    if ($comment_update) {
        $msg = "Comment updated successfully.";
        header("Location: ../Comment/manage_comments.php?msg=$msg&color=green");
    } else {
        $msg = "Failed to update.";
        header("Location: ../Comment/manage_comments.php?msg=$msg&color=red");
    }
}


//Active/Inactive Comment Ends


//Update Profile


if (isset($_POST['update_profile'])) {
        $user_id = $_POST['user_id'];
        $role_id = $_POST['role_id'];
        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $email = $_POST['email'];
        $address = $_POST['address'];
        $password = $_POST['password'];
        $gender = $_POST['gender'];
        $date_of_birth = $_POST['date_of_birth'];


        $folder = "../../User_Image";

        $filename   = rand().$_FILES['image']['name'];
        $temp_name  = $_FILES['image']['tmp_name'];
    

   
        move_uploaded_file($temp_name, $folder."/".$filename);


   
        $update_User_profile = "UPDATE user SET first_name='".$first_name."', last_name='".$last_name."', email='".$email."', address='".$address."', password='".$password."', gender='".$gender."', date_of_birth='".$date_of_birth."', user_image='".$filename."' WHERE user_id=".$user_id;
        $update = mysqli_query($connection, $update_User_profile);
      
  
        if ($role_id == 2) {
             if ($update) {
                    $msg = "User updated successfully.";
                    header("Location: ../../User_panel/Profile.php?msg=$msg&color=green");
                } else {
                    $msg = "Failed to update user.";
                    header("Location: ../../User_panel/Profile.php?msg=$msg&color=red");
                }

        }
        if ($role_id == 1) {
            if ($update) {
                    $msg = "User updated successfully.";
                    header("Location: ../Profile/Profile.php?msg=$msg&color=green");
                } else {
                    $msg = "Failed to update user.";
                    header("Location: ../Profile/Profile.php?msg=$msg&color=red");
                }
            
        }
    } 



//Update User Request


if (isset($_POST['update_request'])) {
    $user = $_POST['user_id'];
    $request = $_POST['is_approved'];

      

    
    $update_request = "UPDATE user SET is_approved = '$request' WHERE user_id = ".$user;
    $Result = mysqli_query($connection, $update_request);


    
    if ($Result) {
        header("Location: ../User/manage_user.php?msg=Request updated successfully&color=purple");
        if($request == 'Approved'){
            $update_is_active = "UPDATE user SET is_active = 'Active' WHERE user_id = ".$user;
            $status = mysqli_query($connection, $update_is_active);
            $mail = new PHPMailer();
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->Port = 587;
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->SMTPAuth = true;
                $mail->Username = 'sameerbaladi9@gmail.com';
                $mail->Password = 'jrbzedbupgmhwfib';
                $mail->setFrom('sameerbaladi9@gmail.com', 'Mr Admin');
                $mail->addReplyTo('sameerbaladi9@gmail.com', 'Admin');
                $mail->AddCc('sameerbaladi9@gmail.com');
                $mail->AddBcc('dralih@gmail.com');
                $mail->addAddress($email, $first_name);
                $mail->Subject = 'Request For Account Approval';
                $mail->msgHTML('Your Account Has Been Approved And Activated Now You Can Login Thanks..');
                $mail->send();
            
        }
        elseif ($request == 'Rejected') {
            $update_is_active = "UPDATE user SET is_active = 'InActive' WHERE user_id = ".$user;
            $status = mysqli_query($connection, $update_is_active);
            $mail = new PHPMailer();
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->Port = 587;
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->SMTPAuth = true;
                $mail->Username = 'sameerbaladi9@gmail.com';
                $mail->Password = 'jrbzedbupgmhwfib';
                $mail->setFrom('sameerbaladi9@gmail.com', 'Mr Admin');
                $mail->addReplyTo('sameerbaladi9@gmail.com', 'Admin');
                $mail->AddCc('sameerbaladi9@gmail.com');
                $mail->AddBcc('dralih@gmail.com');
                $mail->addAddress($email, $first_name);
                $mail->Subject = 'Registration on the Online Blogging Application Plateform';
                $mail->msgHTML('Your Request Has Been Rejected ..');
                $mail->send();
           
        }
        
    } else {
        header("Location: ../User/manage_user.php?msg=Try Again For Request&color=yellow");
      
    }
}



    if (isset($_POST['update_is_active'])) {
        $user_id = $_POST['user_id'];
        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $email = $_POST['email'];
        $address = $_POST['address'];
        $password = $_POST['password'];
        $gender = $_POST['gender'];
        $status = $_POST['is_active'];
        $date_of_birth = $_POST['date_of_birth'];


        $folder = "../../User_Image";

        $filename   = rand().$_FILES['image']['name'];
        $temp_name  = $_FILES['image']['tmp_name'];
    

   
        move_uploaded_file($temp_name, $folder."/".$filename);


   
        $updateUserQuery = "UPDATE user SET first_name='".$first_name."', last_name='".$last_name."', email='".$email."', address='".$address."', password='".$password."', gender='".$gender."', is_active='".$status."', date_of_birth='".$date_of_birth."', user_image='".$filename."' WHERE user_id=".$user_id;
        $update = mysqli_query($connection, $updateUserQuery);
      
  
        if ($update) {

            if($status == 'Active'){
                $mail = new PHPMailer();
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->Port = 587;
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->SMTPAuth = true;
                $mail->Username = 'sameerbaladi9@gmail.com';
                $mail->Password = 'jrbzedbupgmhwfib';
                $mail->setFrom('sameerbaladi9@gmail.com', 'Mr Admin');
                $mail->addReplyTo('sameerbaladi9@gmail.com', 'Admin');
                $mail->AddCc('sameerbaladi9@gmail.com');
                $mail->AddBcc('dralih@gmail.com');
                $mail->addAddress($email, $first_name);
                $mail->Subject = 'Account Actiated';
                $mail->msgHTML('Your Account Has Been Activated Now You Can Login Thanks..');
                $mail->send();
            }
            elseif($status == 'InActive'){
                $mail = new PHPMailer();
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->Port = 587;
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->SMTPAuth = true;
                $mail->Username = 'sameerbaladi9@gmail.com';
                $mail->Password = 'jrbzedbupgmhwfib';
                $mail->setFrom('sameerbaladi9@gmail.com', 'Mr Admin');
                $mail->addReplyTo('sameerbaladi9@gmail.com', 'Admin');
                $mail->AddCc('sameerbaladi9@gmail.com');
                $mail->AddBcc('dralih@gmail.com');
                $mail->addAddress($email, $first_name);
                $mail->Subject = 'Account InActivated';
                $mail->msgHTML('Your Account Has Been InActivated You have To Wait For Login Untill Your Account Is Activated. Thanks,');
                $mail->send();
            }
            $msg = "User updated successfully.";
            header("Location: ../User/approved_user.php?msg=$msg&color=green");
        } else {
            $msg = "Failed to update user.";
            header("Location: ../User/approved_user.php?msg=$msg&color=red");
        }
    } 


    date_default_timezone_set("Asia/karachi");
    
if(isset($_POST['Add_user']))
{
      extract($_POST);

    $folder = "../../User_Image";
    if(!is_dir($folder)){
        if(!mkdir($folder)){
            $message = "Folder Not Created";
            header("location:Add_user.php?msg=$message&color=red");
            die;
        }
    }
    
    
    $filename   = rand().$_FILES['image']['name'];
    $temp_name  = $_FILES['image']['tmp_name'];
    

   
    move_uploaded_file($temp_name, $folder."/".$filename);

    $current_time = date("Y-m-d g:i:s a");
    $Approved = "Approved";
     
    $insertUserQuery = "INSERT INTO user(role_id, first_name, last_name, email, password, gender, date_of_birth, user_image, address, is_approved, updated_at)
    VALUES(?,?,?,?,?,?,?,?,?,?,?)";
    
    $stmt_insert = mysqli_prepare($connection, $insertUserQuery);
    
    mysqli_stmt_bind_param($stmt_insert, 'sssssssssss', $role, $first_name, $last_name, $email, $password, $gender, $date_of_birth, $filename, $address, $Approved, $current_time);
    
    $msg = "";
    if(mysqli_stmt_execute($stmt_insert))
    {
        $mail = new PHPMailer();
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->Port = 587;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->SMTPAuth = true;
        $mail->Username = 'sameerbaladi9@gmail.com';
        $mail->Password = 'jrbzedbupgmhwfib';
        $mail->setFrom('sameerbaladi9@gmail.com', 'Admin');
        $mail->addReplyTo($email, 'User');
        // $mail->AddCc($email);
        $mail->addAddress($email, 'Admin');
        $mail->Subject = 'New User Registration';
        $mail->msgHTML("A new user has registered with the following details:\n\nName: $first_name\nEmail: $email\nPassword: $password");
        $mail->send();
        $msg = "User Account Registered";
        header("location: ../User/Add_user.php?msg=$msg&color=green");  

    }
    else
    {
        $msg = "Try Again";
        header("location: ../User/Add_user.php?msg=$msg&color=red");
    }

}

    
if(isset($_POST['Add_post']))
{
    $blog_name = $_POST['blog'];
    $post_title = $_POST['title'];
    $post_summary = $_POST['summary'];
    $post_description = $_POST['description'];
    $post_status = $_POST['Post_Status'];



    $current_time = date("Y-m-d g:i:s a");

    $folder = "../Post/Post_Image";
    if(!is_dir($folder)){
        if(!mkdir($folder)){
            $message = "Folder Not Created";
            header("location:Add_user.php?msg=$message&color=red");
            die;
        }
    }
    
    
    $filename   = rand().$_FILES['image']['name'];
    $temp_name  = $_FILES['image']['tmp_name'];
    

   
    move_uploaded_file($temp_name, $folder."/".$filename);
    
    $insert = "INSERT INTO post(blog_id, post_title, post_summary, post_description, featured_image, post_status , updated_at)
            VALUES('".$blog_name."', '".$post_title."', '".$post_summary."', '".$post_description."', '".$filename."', '".$post_status."',  '".$current_time."');";

    $result = mysqli_query($connection, $insert);


        $post_category = $_POST['category'];
        $post_attachment_title = $_POST['Attachment_title'];
      

    $msg = "";
    if($result)
    {

            $post_last_id =  mysqli_insert_id($connection);
            
            $insert_post_category = "INSERT INTO post_category(post_id, category_id, updated_at)
                VALUES('".$post_last_id."', '".$post_category."', '".$current_time."');";

            $result_category = mysqli_query($connection, $insert_post_category);

            
            $Image_count = 0;

            $folder = "../Post/Post_Attachment_Image";
            if(!is_dir($folder)){
                if(!mkdir($folder)){
                    $message = "Folder Not Created";
                    header("location:Add_user.php?msg=$message&color=red");
                    die;
                }
            }
                
            foreach ($_FILES['multiple_Image']['name'] as $key => $value) {
                $original_name  = $_FILES['multiple_Image']['name'][$key];      
                $attachment      = rand()."_".$_FILES['multiple_Image']['name'][$key];        
                $temp_name     = $_FILES['multiple_Image']['tmp_name'][$key];       
                
            
              $insert_attachment = "INSERT INTO post_atachment(post_id, post_attachment_title,  post_attachment_path, updated_at)
                    VALUES('".$post_last_id."', '".$post_attachment_title."', '".$attachment."' ,  '".$current_time."');";

                $result_attachment = mysqli_query($connection, $insert_attachment);
                 

            
                if(move_uploaded_file($temp_name, $folder."/".$attachment)){
                    $Image_count++;
                }
        }


       


            
          
           
        $msg = "Post Added:";
        header("location: ../Post/Add_post.php?msg=$msg&color=green");  

    }
    else
    {
        $msg = "Try Again:";
        header("location: ../Post/Add_post.php?msg=$msg&color=red");
    }



}

    
if(isset($_POST['Add_category']))
{
     $title = $_POST['title'];
     $description = $_POST['description'];
     $status = $_POST['status'];
     



    $current_time = date("Y-m-d g:i:s a");
    
    $insertQuery = "INSERT INTO category(category_title, category_description, category_status, updated_at)
    VALUES('".$title."','".$description."','".$status."','".$current_time."');";
    $result = mysqli_query($connection, $insertQuery);

    

    $msg = "";
    if($result)
    {

        $msg = "Category Created";
        header("location: ../Category/Add_category.php?msg=$msg&color=green");  

    }
    else
    {
        $msg = "Try Again";
        header("location: ../Category/Add_category.php?msg=$msg&color=red");
    }

}


   
if(isset($_POST['Add_blog']))
{
  extract($_POST);
   

  $folder = "../Blog/Blog_Image";
    if(!is_dir($folder)){
        if(!mkdir($folder)){
            $message = "Folder Not Created";
            header("location:Add_user.php?msg=$message&color=red");
            die;
        }
    }
    
    
    $filename   = rand().$_FILES['image']['name'];
    $temp_name  = $_FILES['image']['tmp_name'];
    

   
    move_uploaded_file($temp_name, $folder."/".$filename);
    $current_time = date("Y-m-d g:i:s a");
    $current_user = $_SESSION['user']['user_id'];

   $insert_blog = "INSERT INTO blog(user_id ,blog_title, post_per_page, blog_background_image, blog_status, updated_at)
   VALUES(?,?,?,?,?,?);";
    $stmt_insert = mysqli_prepare($connection,$insert_blog);

    mysqli_stmt_bind_param($stmt_insert,'ssssss',$current_user, $title,  $number,  $filename,  $status, $current_time);

    $msg = "";
    if(mysqli_stmt_execute($stmt_insert))
    {

        $msg = "Blog Created";
        header("location: ../Blog/Add_page.php?msg=$msg&color=green");  

    }
    else
    {
        $msg = "Try Again";
        header("location: ../Blog/Add_page.php?msg=$msg&color=red");
    }



}






?>