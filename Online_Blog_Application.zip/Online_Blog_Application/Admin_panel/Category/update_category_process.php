<?php
include_once("../../Connection/Connection.php");
include_once("../Session_Admin.php");

if (isset($_GET['id'])) {
    $category_id = $_GET['id'];


    $category_query = "SELECT * FROM category WHERE category_id = ".$category_id;
    $result = mysqli_query($connection, $category_query);

    if (mysqli_num_rows($result) > 0) {
        $category = mysqli_fetch_assoc($result);
    

        ?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update User</title>
    <link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../Css/Home.css">
    <link rel="stylesheet" type="text/css" href="../../Css/sidebar.css">

</head>
<body>
<?php
    include_once("../NavBar/navbar.php");

?>
<div class="container-fluid">
    <div class="row">
        <?php
        include_once("../Sidebar/sidebar.php");
        ?>
        <div class="col-10 p-2">
            <h3 class="text-center">Update category</h3>
            <form method="post" action="../Process/update_process.php" enctype="multipart/form-data">
                <input type="hidden" name="category_id" value="<?php echo $category['category_id']; ?>">
                <div class="mb-3">
                    <label for="first_name" class="form-label">Title</label>
                    <input type="text" class="form-control" id="category_title" name="title" value="<?php echo $category['category_title']; ?>" required>
                </div>
                <div class="mb-3">
                    <label for="last_name" class="form-label">Description</label>
                    <input type="text" class="form-control" id="category_description" name="description" value="<?php echo $category['category_description']; ?>" required>
                </div>
                
                
               
                <div class="mb-3">
                    <label class="form-label">Category Status</label>
                      <?php
                    $active ="";
                    $inactive ="";

                    if($category['category_status']=='Active'){
                        $active = 'selected';
                    }
                    if($category['category_status']=='InActive'){
                        $inactive = 'selected';

                    }
                    ?>
                    <select class="form-select" id="category_status" name="status" required>
                        <option value="Active" <?php echo $active; ?>>Active</option>
                        <option value="InActive" <?php echo $inactive; ?>>InActive</option>
                    </select>
                </div>
                <input type="submit" name="update_category" value="Update Category" class="btn btn-primary">
                <!-- <button type="submit" class="btn btn-primary">Update Category</button> -->
            </form>
        </div>
    </div>
</div>
<script type="text/javascript" src="../../bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>

        <?php


    }


}




?>