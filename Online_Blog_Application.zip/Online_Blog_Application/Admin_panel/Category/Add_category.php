<?php
    include_once("../Session_Admin.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Category</title>
    <link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../Css/Register.css">
    <link rel="stylesheet" type="text/css" href="../../Css/sidebar.css">


</head>
<body>
<?php
    include_once("../NavBar/navbar.php");

?>

      <div class="container-fluid">
        <div class="row">
          
			<?php
            include_once("../Sidebar/sidebar.php");
            ?>
            
            <div class="col-6 pb-5 ps-5 pe-5 mx-auto" >
		 	        <form action="../Process/update_process.php" method="POST" enctype="multipart/form-data">
				        <h5 class="fw-normal text-center">Add Category</h5>
                <div class="col-12 text-center fw-bold text-white">
                  <?php 
                    if(isset($_GET['msg']))
                    {
                      ?>
                        <p  class="alert alert-primary" role="alert">
                          
                          <?php echo $_GET['msg']; ?>
                        </p>
                      <?php
                    }

                  ?> 
                
              </div>
                  	<div class="row">
                  		<div class="form-outline mb-1 col-12">
                    		<label class="form-label" for="form2Example17">Category Title</label>
                    		<input type="text" id="form2Example17" class="form-control form-control-lg" placeholder="Category title" name="title" />
                  		</div>
                  	</div>
                

                    <div class="form-outline mb-1">
                    	<label class="form-label" for="form2Example27" >Category Description</label>
                    	<textarea name="description" id="description" cols="30" rows="3" class="form-control form-control-lg"></textarea>
                  	</div>
                      <div class="row">
                  		<div class="form-outline mb-1 col-12">
                    		<label class="form-label" for="form2Example17">Status:</label>
                    		<select class="form-select" name="status" >
							  
							  <option value="Active">Active</option>
							  <option value="Inactive">Inactive</option>
							</select>
                  		</div>
                  	</div>
                      
                    
                    
					<div class="row align-items-center pt-1 mt-2 mb-1">
						<div class="col-12 ">
						  	<input class="btn btn-lg btn-block" type="submit" value="Add Category" name="Add_category" style="background-color: #424874;">
						</div>
					</div>
			
	            </form>
		
			</div>

        </div>

    </div>
	
	
  
    

              
</body>
</html>