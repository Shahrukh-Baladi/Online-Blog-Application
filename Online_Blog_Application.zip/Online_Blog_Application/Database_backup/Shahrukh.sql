/*
SQLyog Ultimate v12.5.0 (64 bit)
MySQL - 10.4.27-MariaDB : Database - Shahrukh_Baladi_19658
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`Shahrukh_Baladi_19658` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `Shahrukh_Baladi_19658`;

/*Table structure for table `blog` */

DROP TABLE IF EXISTS `blog`;

CREATE TABLE `blog` (
  `blog_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `blog_title` varchar(50) DEFAULT NULL,
  `post_per_page` int(11) DEFAULT NULL,
  `blog_background_image` text DEFAULT NULL,
  `blog_status` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`blog_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `blog_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `blog` */

insert  into `blog`(`blog_id`,`user_id`,`blog_title`,`post_per_page`,`blog_background_image`,`blog_status`,`created_at`,`updated_at`) values 
(20,18,'IPL',2,'1837007013wp6194569-cricket-ipl-wallpapers.jpg','Active','2023-05-24 09:30:46','2023-05-20 03:31:11'),
(24,18,'Movie',1,'242860327fGai2J8-minions-wallpaper.jpg','Active','2023-05-24 10:48:32','2023-05-23 10:13:45'),
(26,41,'Cartoon Network',3,'1335874477wp1925773-courage-the-cowardly-dog-wallpapers.jpg','Active','2023-05-24 10:52:29','2023-05-24 10:52:29'),
(27,41,'Netflix',2,'1082417754wp10275765-game-of-thrones-laptop-wallpapers.jpg','Active','2023-05-24 11:00:29','2023-05-24 10:55:55');

/*Table structure for table `category` */

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_title` varchar(100) DEFAULT NULL,
  `category_description` text DEFAULT NULL,
  `category_status` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `category` */

insert  into `category`(`category_id`,`category_title`,`category_description`,`category_status`,`created_at`,`updated_at`) values 
(13,'Fantasy','lorem','Active','2023-05-20 14:45:21','2023-05-20 02:45:21'),
(14,'Fiction','lorem','Active','2023-05-20 14:45:39','2023-05-20 02:45:39'),
(15,'Drama','lorem','Active','2023-05-24 10:48:56','2023-05-20 02:45:54'),
(16,'Web Series','Lorem','Active','2023-05-24 10:49:14','2023-05-23 10:04:46'),
(17,'World Cup','Cricket World Cup','Active','2023-05-23 10:11:16','2023-05-23 10:11:16'),
(18,'Cartoons','cartoons','Active','2023-05-24 10:52:42','2023-05-24 10:52:42');

/*Table structure for table `following_blog` */

DROP TABLE IF EXISTS `following_blog`;

CREATE TABLE `following_blog` (
  `follow_id` int(11) NOT NULL AUTO_INCREMENT,
  `follower_id` int(11) DEFAULT NULL,
  `blog_following_id` int(11) DEFAULT NULL,
  `status` enum('Followed','Unfollowed') DEFAULT 'Followed',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`follow_id`),
  KEY `blog_following_id` (`blog_following_id`),
  KEY `follower_id` (`follower_id`),
  CONSTRAINT `following_blog_ibfk_1` FOREIGN KEY (`blog_following_id`) REFERENCES `blog` (`blog_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `following_blog_ibfk_2` FOREIGN KEY (`follower_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `following_blog` */

/*Table structure for table `post` */

DROP TABLE IF EXISTS `post`;

CREATE TABLE `post` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `blog_id` int(11) DEFAULT NULL,
  `post_title` varchar(200) NOT NULL,
  `post_summary` text NOT NULL,
  `post_description` longtext NOT NULL,
  `featured_image` text DEFAULT NULL,
  `post_status` enum('Active','InActive') DEFAULT NULL,
  `is_comment_allowed` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`post_id`),
  KEY `blog_id` (`blog_id`),
  CONSTRAINT `post_ibfk_1` FOREIGN KEY (`blog_id`) REFERENCES `blog` (`blog_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `post` */

insert  into `post`(`post_id`,`blog_id`,`post_title`,`post_summary`,`post_description`,`featured_image`,`post_status`,`is_comment_allowed`,`created_at`,`updated_at`) values 
(90,20,'RCB V/S TITANS','Titans won by 6 wickets with 5 balls remaining.','Titans won by 6 wickets (with 5 balls remaining)','742944092wp6194569-cricket-ipl-wallpapers.jpg','Active',1,'2023-05-24 10:43:30','2023-05-23 03:20:52'),
(91,24,'Summer','What good is the warmth of summer, without the cold of winter to give it sweetness.','What good is the warmth of summer, without the cold of winter to give it sweetness.','2083719385wp4221567-crescent-moon-wallpapers.jpg','Active',1,'2023-05-24 10:50:47','2023-05-24 10:50:47'),
(92,26,'Tom & Jerry','Tom And Jerry','Ohana means family, family means nobody gets left behind. Or forgotten','384433383wp1972851-tom-and-jerry-wallpapers.jpg','Active',1,'2023-05-24 10:55:06','2023-05-24 10:55:06'),
(93,27,'Winter Is Coming','You only live once, but if you do it right, once is enough.','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','2099357413wp10275761-game-of-thrones-laptop-wallpapers.jpg','Active',1,'2023-05-24 10:57:35','2023-05-24 10:57:35'),
(94,27,'Spider man','Spider man','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','480649712wp3636413-marvels-spider-man-wallpapers.jpg','Active',1,'2023-05-24 10:59:40','2023-05-24 10:59:40');

/*Table structure for table `post_atachment` */

DROP TABLE IF EXISTS `post_atachment`;

CREATE TABLE `post_atachment` (
  `post_atachment_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) DEFAULT NULL,
  `post_attachment_title` varchar(200) DEFAULT NULL,
  `post_attachment_path` text DEFAULT NULL,
  `is_active` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`post_atachment_id`),
  KEY `fk1` (`post_id`),
  CONSTRAINT `fk1` FOREIGN KEY (`post_id`) REFERENCES `post` (`post_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `post_atachment` */

insert  into `post_atachment`(`post_atachment_id`,`post_id`,`post_attachment_title`,`post_attachment_path`,`is_active`,`created_at`,`updated_at`) values 
(114,90,'Game Of Throne','110792273_wp4402745-game-of-thrones-laptop-wallpapers.jpg',NULL,'2023-05-23 15:24:20','2023-05-23 11:43:14'),
(117,91,'Data','1184001792_wp1972851-tom-and-jerry-wallpapers.jpg',NULL,'2023-05-24 10:50:48','2023-05-24 10:50:47'),
(118,91,'Data','1752264942_wp10166519-game-of-thrones-laptop-wallpapers.jpg',NULL,'2023-05-24 10:50:48','2023-05-24 10:50:47'),
(119,91,'Data','1879752815_wp11855091-john-wick-chapter-4-hd-wallpapers.jpg',NULL,'2023-05-24 10:50:48','2023-05-24 10:50:47'),
(120,92,'Cartoons','745728354_fGai2J8-minions-wallpaper.jpg',NULL,'2023-05-24 10:55:06','2023-05-24 10:55:06'),
(121,92,'Cartoons','2100912560_wp1925773-courage-the-cowardly-dog-wallpapers.jpg',NULL,'2023-05-24 10:55:07','2023-05-24 10:55:06'),
(122,92,'Cartoons','24788141_wp1972851-tom-and-jerry-wallpapers.jpg',NULL,'2023-05-24 10:55:07','2023-05-24 10:55:06'),
(123,93,'Game Of Throne','1113317988_wp2131711-game-of-thrones-laptop-wallpapers.jpg',NULL,'2023-05-24 10:57:35','2023-05-24 10:57:35'),
(124,93,'Game Of Throne','1749965737_wp4402745-game-of-thrones-laptop-wallpapers.jpg',NULL,'2023-05-24 10:57:35','2023-05-24 10:57:35'),
(125,93,'Game Of Throne','395410192_wp5284950-game-of-thrones-laptop-wallpapers.jpg',NULL,'2023-05-24 10:57:35','2023-05-24 10:57:35'),
(126,94,'Data','271226323_fGai2J8-minions-wallpaper.jpg',NULL,'2023-05-24 10:59:40','2023-05-24 10:59:40'),
(127,94,'Data','1187446518_wp1978390-game-of-thrones-season-2-wallpapers.jpg',NULL,'2023-05-24 10:59:40','2023-05-24 10:59:40'),
(128,94,'Data','1588916564_wp11855091-john-wick-chapter-4-hd-wallpapers.jpg',NULL,'2023-05-24 10:59:40','2023-05-24 10:59:40');

/*Table structure for table `post_category` */

DROP TABLE IF EXISTS `post_category`;

CREATE TABLE `post_category` (
  `post_category_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`post_category_id`),
  KEY `post_id` (`post_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `post_category_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `post` (`post_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `post_category_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `post_category` */

insert  into `post_category`(`post_category_id`,`post_id`,`category_id`,`created_at`,`updated_at`) values 
(75,90,16,'2023-05-24 10:43:30','2023-05-23 03:20:52'),
(76,91,15,'2023-05-24 10:50:48','2023-05-24 10:50:47'),
(77,92,18,'2023-05-24 10:55:06','2023-05-24 10:55:06'),
(78,93,16,'2023-05-24 10:57:35','2023-05-24 10:57:35'),
(79,94,14,'2023-05-24 10:59:40','2023-05-24 10:59:40');

/*Table structure for table `post_comment` */

DROP TABLE IF EXISTS `post_comment`;

CREATE TABLE `post_comment` (
  `post_comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `is_active` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`post_comment_id`),
  KEY `user_id` (`user_id`),
  KEY `post_id` (`post_id`),
  CONSTRAINT `post_comment_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `post_comment_ibfk_2` FOREIGN KEY (`post_id`) REFERENCES `post` (`post_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `post_comment` */

insert  into `post_comment`(`post_comment_id`,`post_id`,`user_id`,`comment`,`is_active`,`created_at`) values 
(113,90,40,'Hello','Active','2023-05-24 10:38:33'),
(120,90,40,'Hello World','InActive','2023-05-24 10:37:58'),
(121,90,40,'Hello World','InActive','2023-05-24 10:38:13');

/*Table structure for table `role` */

DROP TABLE IF EXISTS `role`;

CREATE TABLE `role` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_type` varchar(50) NOT NULL,
  `is_active` enum('Active','InActive') DEFAULT 'Active',
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `role` */

insert  into `role`(`role_id`,`role_type`,`is_active`) values 
(1,'Admin','Active'),
(2,'User','Active');

/*Table structure for table `setting` */

DROP TABLE IF EXISTS `setting`;

CREATE TABLE `setting` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `setting_key` varchar(100) DEFAULT NULL,
  `setting_value` varchar(100) DEFAULT NULL,
  `setting_status` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`setting_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `setting_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `setting` */

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) DEFAULT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` text NOT NULL,
  `gender` enum('Male','Female') DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `user_image` text DEFAULT NULL,
  `address` text DEFAULT NULL,
  `is_approved` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `is_active` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `Email` (`email`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `user` */

insert  into `user`(`user_id`,`role_id`,`first_name`,`last_name`,`email`,`password`,`gender`,`date_of_birth`,`user_image`,`address`,`is_approved`,`is_active`,`created_at`,`updated_at`) values 
(12,1,'Ali','Jan','Ali_12@gmail.com','123','Female','2000-12-01','1239011108woman.png','Karachi','Approved','Active','2023-05-18 15:47:38','2023-05-11 09:12:37'),
(14,1,'Shahrukh','Baladi','Shahrukh@gmail.com','123','Male','2023-05-01','1854855187464602469man.png','Hyderabad','Approved','Active','2023-05-23 10:50:25','2023-05-11 09:43:22'),
(15,1,'Muhammad','Ali','MuhammadAli@gmail.com','123','Male','1999-02-01','2094774006man(2).png','Larkana','Approved','Active','2023-05-23 12:54:29','2023-05-13 12:05:04'),
(18,1,'Alina','Khan','Alina@gmail.com','11111','Female','1999-09-26','1827255008profile.png','Larkana','Approved','Active','2023-05-23 15:48:03','2023-05-15 10:20:31'),
(19,2,'Alina','Khan','Alina12@gmail.com','123','Female','2023-05-01','138541108woman.png','Larkana','Approved','InActive','2023-05-24 09:32:09','2023-05-18 09:29:07'),
(20,2,'Aliza','Khan','Aliza@gmail.com','123','Female','2023-05-07','971306160profile.png','Larkana','Approved','InActive','2023-05-24 09:32:28','2023-05-18 09:29:35'),
(21,2,'Ali','Khan','Ali@gmail.com','123','Male','2023-06-04','534112652man(2).png','Larkana','Rejected','InActive','2023-05-22 09:16:45','2023-05-18 09:30:29'),
(37,2,'Shahrukh','Baladi','shahrukh99@gmail.com','Sameer123','Male','2000-02-01','83204933464602469man.png','Hyderabad','Approved','Active','2023-05-24 09:32:44','2023-05-23 09:17:51'),
(40,2,'Ali ','Jaan','Alijan12@gmail.com','Sameer123','Male','2019-05-25','730469547man.png','Larkana','Approved','Active','2023-05-24 09:32:59','2023-05-23 09:43:28'),
(41,1,'Shahrukh','Baladi','Shahrukh52@gmail.com','Sameer1234','Male','2023-05-01','1036112036man(2).png','Hyderabad','Approved','Active','2023-05-24 10:29:45','2023-05-23 09:46:27'),
(42,2,'Shahrukh','Khan','srk12@gmail.com','Srk12345','Male','1965-02-11','317072108man (1).png','Delhi','Approved','Active','2023-05-24 09:33:14','2023-05-23 10:59:21');

/*Table structure for table `user_feedback` */

DROP TABLE IF EXISTS `user_feedback`;

CREATE TABLE `user_feedback` (
  `feedback_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `user_email` varchar(100) DEFAULT NULL,
  `feedback` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`feedback_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `user_feedback_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `user_feedback` */

insert  into `user_feedback`(`feedback_id`,`user_id`,`user_name`,`user_email`,`feedback`,`created_at`,`updated_at`) values 
(11,20,'Aliza Khan','Aliza@gmail.com','Plz Upload More Series Like Game Of thrones','2023-05-20 15:08:49','2023-05-20 03:08:49'),
(12,NULL,'Ali Hasan','Ali_Hasan@gmail.com','I like It','2023-05-22 11:41:27','2023-05-22 11:41:27'),
(13,NULL,'Ali ','Khan','Brother you did a great job!','2023-05-23 12:03:00','2023-05-23 12:03:00');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
