<?php



    if (isset($_POST['submit'])){
    
     extract($_POST); }

        use PHPMailer\PHPMailer\PHPMailer;
        use PHPMailer\PHPMailer\SMTP;
        use PHPMailer\PHPMailer\Exception;

        require 'PHPMailer/src/PHPMailer.php';
        require 'PHPMailer/src/SMTP.php';
        require 'PHPMailer/src/Exception.php';


        $mail = new PHPMailer();
        $mail->isSMTP();

        $mail->Host = 'smtp.gmail.com';
        $mail->Port = 587;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->SMTPAuth = true;
        $mail->Username = 'mr.intern11@gmail.com';
        $mail->Password = 'sqgumlcmvjtcumgt';
        $mail->setFrom($from, 'Mr Intern');
        $mail->addReplyTo('mr.intern11@gmail.com', 'Hidaya Intern');
        $mail->AddCc('mr.intern11@gmail.com');
        $mail->AddBcc('itians110@gmail.com');
        $mail->addAddress($to, 'Hidaya Trust');
        $mail->Subject = $sub;
        $mail->msgHTML($message);

        $mail->addAttachment('image.jpg');
        if ($mail->send()) {
            echo "<b>Your Email was Sent </b>"; 
        } else {
            echo 'Email not sent!'.$mail->ErrorInfo;;
        }





?>