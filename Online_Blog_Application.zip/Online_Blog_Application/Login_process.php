<?php
 	

 	use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    require 'PHPMailer/src/PHPMailer.php';
    require 'PHPMailer/src/SMTP.php';
    require 'PHPMailer/src/Exception.php';

include_once("Connection/Connection.php");
session_start();

	
	if(isset($_POST['Login']))
	{
		
		extract($_POST);
		$flag = true;


		$login_query = "SELECT * FROM `user` 
		WHERE `user`.`email` = ?
		AND `user`.`password` = ?";

		$statement = mysqli_prepare($connection,$login_query);

		mysqli_stmt_bind_param($statement,"ss",$email,$password);

		mysqli_stmt_execute($statement);

		$data = mysqli_stmt_get_result($statement);

		if($data->num_rows > 0)
		{
			while($user_info = mysqli_fetch_assoc($data)){
				
				if($email==$user_info['email'] && $password==$user_info['password']){
					if ($user_info['is_active']=="Active" && $user_info['role_id']==1){
						$flag=false;
						$_SESSION['user']=$user_info;
						header("location: Admin_panel/Admin_dashboard/Admin.php");
						}
						else if ($user_info['is_approved']=="Approved" && $user_info['is_active']=="InActive")
						{
						$flag=false;
						header('location:login.php?msg=your Account Is InActive');

						}
						else if ($user_info['is_approved']=="Pending")
						{
						$flag=false;
						header('location:login.php?msg=Please Wait For Your Approval');

						}
						else if ($user_info['is_approved']=="Rejected")
						{
						$flag=false;
						header('location:login.php?msg=Your Request Has Been Rejected');

						}						
						
						else if ($user_info['is_approved']=="Approved" && $user_info['is_active']=="Active" && $user_info['role_id']==2)
						{
						$flag=false;
						$_SESSION['user']=$user_info;							 
						header('location:User_panel/User.php');

						}
						else{
							$flag=false;
							 header('location:login.php?msg=your Accout has DeActiveted');
							 }
				}
			}
		}
		if ($flag) {
			header('location:login.php?msg=Please Enter Correct Email And password');
			
		  }
		

	}

	

	


		
?>