<div class="container-fluid">
	<!-- Footer -->
<footer class="text-center text-lg-start bg-white text-muted">

  <!-- Section: Social media -->

  <!-- Section: Links  -->
  <section class="">
    <div class="container text-center text-md-start mt-5">
      <!-- Grid row -->
      <div class="row mt-3">
        <!-- Grid column -->
        <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
          <!-- Content -->
          <h6 class="text-uppercase fw-bold mb-4">
            <i class="fas fa-gem me-3 text-secondary"></i>online Blogging Application
          </h6>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. 
          </p>
        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
          <!-- Links -->
          <h6 class="text-uppercase fw-bold mb-4">
            Category
          </h6>
          <?php
            $getQuery = "SELECT * FROM `category` WHERE category_status = 'Active' LIMIT 4";
            $result = mysqli_query($connection,$getQuery);

                                     while ($row = mysqli_fetch_assoc($result)) 
                                    {
                                        ?>
                    
                                   
          <p>
            <a class="dropdown-item text-dark" href="Show_category.php?id=<?php echo $row['category_id']; ?>" >
                                            <?php echo $row['category_title']; ?>
                                        </a>
          </p>
               <?php   
                                    }
                               
          ?>
        </div>
       
        <!-- Grid column -->
        <div class="col-md-4 col-lg-3 col-xl-3  mb-md-0 mb-4">
          <!-- Links -->
          <h6 class="text-uppercase fw-bold mb-4 ">Contact</h6>
          <p><i class="fas fa-home me-3 text-secondary"></i> Jamshoro, Sindh, Pakistan</p>
          <p>
            <i class="fas fa-envelope me-3 text-secondary"></i>
            Admin@gmail.com
          </p>
          <p><i class="fas fa-phone me-3 text-secondary"></i> +92 0310-0000000</p>
          <p><i class="fas fa-print me-3 text-secondary"></i> +92 0310-0000000</p>
        </div>
        <!-- Grid column -->
      </div>
      <!-- Grid row -->
    </div>
  </section>
  <!-- Section: Links  -->

  <!-- Copyright -->
  <div class="text-center p-4" style="background-color: rgba(0, 0, 0, 0.025);">
    © 2023 Copyright:
    <a class="text-reset fw-bold">Online Blog Application</a>
  </div>
  <!-- Copyright -->
</footer>
<!-- Footer -->

</div>