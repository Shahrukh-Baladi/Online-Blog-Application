<?php
  
  require_once("Connection/Connection.php");
  require_once('Session.php');




?>

<!DOCTYPE html>
<html>
<head>
	<title>Forget Password</title>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <?php
    include_once("NavBar/navbar.php");
    ?>

	<div class="row">
		<div class="card text-center mx-auto mt-5" style="width: 500px;">
		    <div class="card-header bg-white">Password Reset</div>
			<div class="text-center">
          <?php 
                    if(isset($_GET['msg']))
                    {
                      ?>
                        <p style="background-color: green;">
                          
                          <?php echo $_GET['msg']; ?>
                        </p>
                      <?php
                    }

                  ?> 
            </div>
		    <div class="card-body px-5">
		      	<form action="forget_process.php" method="POST">
		      		<p class="card-text py-2">
		                Enter your email address and we'll send you an email with instructions to reset your password.
		        	</p>
		            <div class="form-outline">
		               <label class="form-label" for="typeEmail">Email input</label>
		               <input type="email" id="typeEmail" class="form-control mb-2" name="email" placeholder="Email" />
		            </div>
		        	<input type="submit" value="Forget" name="forget"  class="btn btn-success bg-gradient" style="background-color: #424874;">
		      	</form>
		        
		    </div>
		</div>
	</div>

</body>
</html>